 <?php
/*

Template Name: Investor Relations Page Template

*/
?>
	<?php
	$investor_relations_banner_image = get_field('investor_relations_banner_image');
	$investor_relations_banner_first_title = get_field('investor_relations_banner_first_title');
	$investor_relations_banner_second_title = get_field('investor_relations_banner_second_title');
	?>
	<section class="inner-banner" style="background-image: url(<?php echo $investor_relations_banner_image['url']; ?>);">
	    <div class="banner-layout">
	      	<div class="title container">
	          <h5><?php echo $investor_relations_banner_first_title; ?></h5>
	          <h2><?php echo $investor_relations_banner_second_title; ?></h2>
	      	</div>
    	</div>
	</section>
	<?php
	$exchange_announcements_first_title = get_field('exchange_announcements_first_title');
	$exchange_announcements_second_title = get_field('exchange_announcements_second_title');
	?>
	<section class="investor-exchange">
		<div class="container">
			<div class="title">
				<h5><?php echo $exchange_announcements_first_title; ?></h5>
				<h2><?php echo $exchange_announcements_second_title; ?></h2>
			</div>
			<?php if( have_rows('exchange_announcements_first_block') ): ?>
			<div class="first-exchange">
				<?php while( have_rows('exchange_announcements_first_block') ): the_row(); 
				$title = get_sub_field('title');
				$icon_type = get_sub_field('icon_type');
				$count = get_sub_field('count');
				$content = get_sub_field('content');
				?>
				<div class="single">
					<div class="title">
						<h3><?php echo $title; ?></h3><img src="<?php echo get_template_directory_uri(); ?>/assets/images/<?php echo $icon_type; ?>" alt=""><span class="red-color-part"><?php echo $count; ?></span>
					</div>
					<div class="content">
						<p><?php echo $content; ?></p>
					</div>
				</div>
				<?php endwhile; ?>
			</div>
			<?php endif; ?>
			<div class="second-exchange">
				<div class="investor">
					<?php if( have_rows('exchange_announcements_second_block') ): ?>
					<?php while( have_rows('exchange_announcements_second_block') ): the_row(); 
					$title = get_sub_field('title');
					$count = get_sub_field('count');
					$icon_type = get_sub_field('icon_type');
					?>
					<div class="single">
						<div class="title">
							<h3><?php echo $title; ?></h3>
						</div>
						<div class="content">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/<?php echo $icon_type; ?>" alt="">
							<?php if($icon_type == "down-arrow.svg"){ ?>
							<span class="red-color-part"><?php echo $count; ?></span>
							<?php }else{ ?>
							<span class="green-color-part"><?php echo $count; ?></span>
							<?php } ?>
						</div>
					</div>
					<?php endwhile; ?>
					<?php endif; ?>
				</div>
			</div>
			<?php 
			$exchange_announcements_cta_text = get_field('exchange_announcements_cta_text');
			$exchange_announcements_cta_link = get_field('exchange_announcements_cta_link');
			?>
			<div class="link-part">
				<a href="<?php echo $exchange_announcements_cta_link; ?>" class="learn-more"><?php echo $exchange_announcements_cta_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
			</div>
		</div>
	</section>
	<?php
	$financial_statements_first_title = get_field('financial_statements_first_title');
	$financial_statements_second_title = get_field('financial_statements_second_title');
	?>
	<section class="financial-statements">
		<div class="container">
			<div class="title">
				<h5><?php echo $financial_statements_first_title; ?></h5>
				<h2><?php echo $financial_statements_second_title; ?></h2>
			</div>
			<div class="block-part">
				<?php
				$financial_statements_first_block_image_part = get_field('financial_statements_first_block_image_part');
				?>
				<div class="img-part">
					<img src="<?php echo $financial_statements_first_block_image_part['url'] ?>" alt="">
				</div>
				<?php
				$financial_statements_middle_block_title = get_field('financial_statements_middle_block_title');
				$financial_statements_middle_block_content = get_field('financial_statements_middle_block_content');
				$financial_statements_middle_block_cta_text = get_field('financial_statements_middle_block_cta_text');
				$financial_statements_middle_block_cta_link = get_field('financial_statements_middle_block_cta_link');
				?>
				<div class="financial-statements">
					<div class="title">
						<h3><?php echo $financial_statements_middle_block_title; ?></h3>
					</div>
					<div class="content">
						<p><?php echo $financial_statements_middle_block_content; ?></p>
					</div>
					<div class="link-part">
						<a href="<?php echo $financial_statements_middle_block_cta_link; ?>"><i class="fa fa-download" aria-hidden="true"></i><span><?php echo $financial_statements_middle_block_cta_text; ?></span></a>
					</div>
				</div>
				<div class="recent-statements">
					<?php
					$recent_statement_title = get_field('recent_statement_title');
					?>
					<div class="title">
						<h4><?php echo $recent_statement_title; ?></h4>
					</div>
					<div class="each-statements">
						<?php if( have_rows('financial_statements_each_recent_statements') ): ?>
						<ul>
							<?php while( have_rows('financial_statements_each_recent_statements') ): the_row(); 
							$title = get_sub_field('title');
							$link = get_sub_field('link');
							?>
							<li><a href="<?php echo $link; ?>"><?php echo $title; ?></a></li>
							<?php endwhile; ?>
						</ul>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php
	$investor_divident_history_bckground_image = get_field('investor_divident_history_bckground_image');
	$investor_divident_history_first_title = get_field('investor_divident_history_first_title');
	$investor_divident_history_second_title = get_field('investor_divident_history_second_title');
	$investor_divident_history_content = get_field('investor_divident_history_content');
	$investor_divident_history_cta_text = get_field('investor_divident_history_cta_text');
	$investor_divident_history_cta_link = get_field('investor_divident_history_cta_link');
	?>
	<section class="dividend-history" style="background-image: url(<?php echo $investor_divident_history_bckground_image['url']; ?>);">
		<div class="container">
			<div class="block-part">
				<div class="title">
					<h5><?php echo $investor_divident_history_first_title; ?></h5>
					<h2><?php echo $investor_divident_history_second_title; ?></h2>
				</div>
				<div class="content">
					<?php echo $investor_divident_history_content; ?>
				</div>
				<div class="link-part">
					<a href="<?php echo $investor_divident_history_cta_link; ?>" class="learn-more"><?php echo $investor_divident_history_cta_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
				</div>
			</div>
		</div>
	</section>
	<?php
	$investor_event_calender_first_title = get_field('investor_event_calender_first_title');
	$investor_event_calender_second_title = get_field('investor_event_calender_second_title');
	?>
	<section class="event-calender">
		<div class="container">
			<div class="event-cal-full">
				<div class="title">
					<h5><?php echo $investor_event_calender_first_title; ?></h5>
					<h2><?php echo $investor_event_calender_second_title; ?></h2>
				</div>
				<div class="event-full-block">
					<?php if( have_rows('investor_event_calender_block') ): ?>
					<?php while( have_rows('investor_event_calender_block') ): the_row(); 
					$title = get_sub_field('title');
					$date = get_sub_field('date');
					$content = get_sub_field('content');
					?>
					<div class="single">
						<div class="title">
							<h3><?php echo $title; ?></h3>
						</div>
						<div class="date-part">
							<span><?php echo $date; ?></span>
						</div>
						<div class="content">
							<p><?php echo $content; ?></p>
						</div>
					</div>
					<?php
					endwhile;
					endif;
					?>
					<!-- <div class="single">
						<div class="title">
							<h3>2019 - Middle east investor seminAR</h3>
						</div>
						<div class="date-part">
							<span>20th February 2019</span>
						</div>
						<div class="content">
							<p>Al-Babtain Power and Telecommunication Company announces it's Interim Financial Results for the period Ending on 2019-09-30 (nine months)</p>
						</div>
					</div>
					<div class="single">
						<div class="title">
							<h3>2019 - Middle east investor seminAR</h3>
						</div>
						<div class="date-part">
							<span>20th February 2019</span>
						</div>
						<div class="content">
							<p>Al-Babtain Power and Telecommunication Company announces it's Interim Financial Results for the period Ending on 2019-09-30 (nine months)</p>
						</div>
					</div>
					<div class="single">
						<div class="title">
							<h3>2019 - Middle east investor seminAR</h3>
						</div>
						<div class="date-part">
							<span>20th February 2019</span>
						</div>
						<div class="content">
							<p>Al-Babtain Power and Telecommunication Company announces it's Interim Financial Results for the period Ending on 2019-09-30 (nine months)</p>
						</div>
					</div> -->
				</div>
				<ul>
					<li class="prev-cal"><a href="JavaScript:Void(0);"><i class="fa fa-angle-left" aria-hidden="true"></i></a></i></li>
					<li class="next-cal"><a href="JavaScript:Void(0);"><i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
				</ul>
			</div>
			<?php
			$investor_event_calender_cta_text = get_field('investor_event_calender_cta_text');
			$investor_event_calender_cta_link = get_field('investor_event_calender_cta_link');
			?>
			<div class="link-part">
				<a href="<?php echo $investor_event_calender_cta_link; ?>" class="learn-more"><?php echo $investor_event_calender_cta_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
			</div>
		</div>
	</section>
	<?php
	$investor_disclosures_first_title = get_field('investor_disclosures_first_title');
	$investor_disclosures_second_title = get_field('investor_disclosures_second_title');
	?>
	<section class="company-disclosures">
		<div class="container">
			<div class="title">
				<h5><?php echo $investor_disclosures_first_title; ?></h5>
				<h2><?php echo $investor_disclosures_second_title; ?></h2>
			</div>
			<div class="full-block-part">
				<div class="left-block">
					<?php if( have_rows('investor_disclosures_each_block') ): ?>
					<?php while( have_rows('investor_disclosures_each_block') ): the_row(); 
					$title = get_sub_field('title');
					$content = get_sub_field('content');
					$cta_text = get_sub_field('cta_text');
					$cta_link = get_sub_field('cta_link');
					?>
					<div class="single">
						<div class="content-full">
							<div class="title">
								<h3><?php echo $title; ?></h3>
							</div>
							<div class="content">
								<p><?php echo $content; ?></p>
							</div>
							<div class="link-part">
								<a href="<?php echo $cta_link; ?>"><i class="fa fa-download" aria-hidden="true"></i><span><?php echo $cta_text; ?></span></a>
							</div>
						</div>
					</div>
					<?php
					endwhile;
					endif;
					?>
				</div>
				<?php
				$investor_recent_disclosurs_title = get_field('investor_recent_disclosurs_title');
				?>
				<div class="right-block">
					<div class="title">
						<h4><?php echo $investor_recent_disclosurs_title; ?></h4>
					</div>
					<ul>
						<?php if( have_rows('investor_recent_disclosurs_list') ): ?>
						<?php while( have_rows('investor_recent_disclosurs_list') ): the_row(); 
						$text = get_sub_field('text');
						$link = get_sub_field('link');
						?>
						<li><a href="<?php echo $link; ?>"><?php echo $text; ?></a></li>
						<?php endwhile; ?>
						<?php endif; ?>
					</ul>
				</div>
			</div>
			<?php
			$investor_disclosures_cta_text = get_field('investor_disclosures_cta_text');
			$investor_disclosures_cta_link = get_field('investor_disclosures_cta_link');
			?>
			<div class="link-part">
				<a href="<?php echo $investor_disclosures_cta_link; ?>" class="learn-more"><?php echo $investor_disclosures_cta_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
			</div>
		</div>
	</section>
	<?php
	$investor_corporate_action_first_title = get_field('investor_corporate_action_first_title');
	$investor_corporate_action_second_title = get_field('investor_corporate_action_second_title');
	?>
	<section class="corporate-actions">
		<div class="container">
			<div class="title">
				<h5><?php echo $investor_corporate_action_first_title; ?></h5>
				<h2><?php echo $investor_corporate_action_second_title; ?></h2>
			</div>
			<div class="block-part">
				<div class="left-block">
					<?php if( have_rows('investor_corporate_action_first_block') ): ?>
					<?php while( have_rows('investor_corporate_action_first_block') ): the_row(); 
					$title = get_sub_field('title');
					$content = get_sub_field('content');
					?>
					<div class="single-block">
						<div class="title">
							<h3><?php echo $title; ?></h3>
						</div>
						<div class="content">
							<p><?php echo $content; ?></p>
						</div>
					</div>
					<?php
					endwhile;
					endif;
					?>
				</div>
				<?php
				$investor_corporate_action_image_block = get_field('investor_corporate_action_image_block');
				?>
				<div class="middle-block">
					<div class="img-part">
						<img src="<?php echo $investor_corporate_action_image_block['url']; ?>" alt="">
					</div>
				</div>
				<div class="right-block">
					<?php if( have_rows('investor_corporate_action_third_block') ): ?>
					<?php while( have_rows('investor_corporate_action_third_block') ): the_row(); 
					$title = get_sub_field('title');
					$content = get_sub_field('content');
					?>
					<div class="single-block">
						<div class="title">
							<h3><?php echo $title; ?></h3>
						</div>
						<div class="content">
							<p><?php echo $content; ?></p>
						</div>
					</div>
					<?php endwhile; ?>
					<?php endif; ?>
				</div>
			</div>
			<?php
			$investor_corporate_action_cta_text = get_field('investor_corporate_action_cta_text');
			$investor_corporate_action_cta_link = get_field('investor_corporate_action_cta_link');
			?>
			<div class="link-part">
				<a href="<?php echo $investor_corporate_action_cta_link; ?>" class="learn-more"><?php echo $investor_corporate_action_cta_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
			</div>
		</div>
	</section>
	<?php 
	$investor_minute_of_meeting_first_title = get_field('investor_minute_of_meeting_first_title');
	$investor_minute_of_meeting_second_title = get_field('investor_minute_of_meeting_second_title');
	?>
	<section class="minute-of-meeting">
		<div class="container">
			<div class="title">
				<h5><?php echo $investor_minute_of_meeting_first_title; ?></h5>
				<h2><?php echo $investor_minute_of_meeting_second_title; ?></h2>
			</div>
			<?php if( have_rows('investor_minute_of_meeting_full_block') ): ?>
			<div class="full-block">
				<?php while( have_rows('investor_minute_of_meeting_full_block') ): the_row(); 
				$title = get_sub_field('title');
				$content = get_sub_field('content');
				?>
				<div class="single">
					<div class="title">
						<h3><?php echo $title; ?></h3>
					</div>
					<div class="content">
						<p><?php echo $content; ?></p>
					</div>
				</div>
				<?php endwhile; ?>
			</div>
			<?php endif; ?>
			<?php
			$investor_minute_of_meeting_cta_text = get_field('investor_minute_of_meeting_cta_text');
			$investor_minute_of_meeting_cta_link = get_field('investor_minute_of_meeting_cta_link');
			?>
			<div class="link-part">
				<a href="<?php echo $investor_minute_of_meeting_cta_link; ?>" class="learn-more"><?php echo $investor_minute_of_meeting_cta_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
			</div>
		</div>
	</section>
	<?php
	$contact_investor_relation_first_title = get_field('contact_investor_relation_first_title');
	$contact_investor_relation_second_title = get_field('contact_investor_relation_second_title');
	?>
	<section class="investor-relations-part">
		<div class="container">
			<div class="title">
				<h5><?php echo $contact_investor_relation_first_title; ?></h5>
				<h2><?php echo $contact_investor_relation_second_title; ?></h2>
			</div>
			<div class="full-block-part">
				<?php if( have_rows('contact_investor_relation_each_investor_relations') ): ?>
				<?php while( have_rows('contact_investor_relation_each_investor_relations') ): the_row(); 
				$image = get_sub_field('image');
				$title = get_sub_field('title');
				$subtitle = get_sub_field('subtitle');
				$mail_id = get_sub_field('mail_id');
				?>
				<div class="single">
					<div class="img-part">
						<img src="<?php echo $image['url']; ?>" alt="">
					</div>
					<div class="content">
						<h3><?php echo $title; ?></h3>
						<span><?php echo $subtitle; ?></span>
						<div class="link">
							<a href="mailto: <?php echo $mail_id; ?>"><?php echo $mail_id; ?></a>
						</div>
					</div>
				</div>
				<?php
				endwhile;
				endif;
				?>
			</div>
		</div>
	</section>