<?php
	$news_inner_banner_image = get_field('news_inner_banner_image');
	$news_inner_banner_first_title = get_field('news_inner_banner_first_title');
	$news_inner_banner_second_title = get_field('news_inner_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $news_inner_banner_image['url']; ?>);">
	<div class="banner-layout">
		<div class="title container" data-aos="fade-up" data-aos-duration="1500">
				<h5><?php echo $news_inner_banner_first_title; ?></h5>
				<h2><?php echo $news_inner_banner_second_title; ?></h2>
		</div>
	</div>
</section>
<?php
$news_inner_date = get_field('news_inner_date');
$news_content = get_field('news_content');
?>
<section class="strength-content-part">
	<div class="container">
		<div class="news-inner-full-block">
			<div class="left-block">
				<div class="date-part-news-inner">
					<span><?php echo $news_inner_date; ?></span>
				</div>
				<?php echo $news_content; ?>
			</div>
			<div class="right-block">
				<div class="right-block-inner">
					<h4>Recent Exchange Announcements</h4>
					<ul>
						<?php  
				      $number = 1;
				      $exchange_args = array(

				        'post_type' => 'exchange',

				        'post_status' => 'publish',

				        'posts_per_page' => 5

				      );
				      $exchange_args = new WP_Query( $exchange_args );
				      if ( $exchange_args->have_posts() ):
				      while ( $exchange_args->have_posts() ) : $exchange_args->the_post();
				      ?>
						<li><a href="<?php the_permalink(); ?>"><?php echo the_title(); ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
					<?php 
					endwhile; 
					endif; 
					wp_reset_postdata();
					?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>