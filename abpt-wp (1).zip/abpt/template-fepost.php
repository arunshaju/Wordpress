<?php

/*

Template Name: Front end Posting Template

*/

?>



<?php get_template_part('templates/page', 'header'); ?>

<?php // get_template_part('templates/content', 'page'); ?>



<form method="post">

	<div class="form-group">

		<label for="book_title">Title</label>

		<input type="text" name="book_title" id="book_title" class="form-control" />

	</div>

	<div class="form-group">

		<label for="book_content">Content</label>

		<textarea name="book_content" id="book_content" class="form-control"></textarea>

	</div>

	<div class="form-group">

		<label for="book_topic">Select Topic</label>

		<select id="book_topic" name="book_topic" class="form-control" tabindex="4">

			<option value="-1" disabled="disabled">Select Topic</option>

			<?php 

			$terms = get_terms( 'topics' );

		 	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){

		     	foreach ( $terms as $term ) {

		       		echo '<option class="level-0" value="'.$term->term_id.'">'.$term->name.'</option>';

		    	}

			}

			?>

		</select>

	</div>

	<input type="hidden" name="post_type" id="post_type" value="book_cpt" />

	<button class="btn btn-primary" name="post_type" id="post_type" value="book_cpt" onClick="insertPost()">Insert Post</button>



	<?php wp_nonce_field( 'book_cpt_nonce_action', 'book_cpt_nonce_field' ); ?>

</form>



<script type="text/javascript">

	function insertPost(){



	}

</script>