<?php
/*

Template Name: Default Content Template

*/
?>
<?php
$default_content_part_banner_image = get_field('default_content_part_banner_image');
$default_content_part_banner_first_title = get_field('default_content_part_banner_first_title');
$default_content_part_banner_second_title = get_field('default_content_part_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $default_content_part_banner_image['url']; ?>);">
  <div class="banner-layout">
    <div class="title container" data-aos="fade-up" data-aos-duration="1500">
        <h5><?php echo $default_content_part_banner_first_title; ?></h5>
        <h2><?php echo $default_content_part_banner_second_title; ?></h2>
    </div>
  </div>
</section>
<section class="strength-content-part">
	<div class="container">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post();
the_content();
endwhile; else: ?>
<p>Sorry, no posts matched your criteria.</p>
<?php endif; ?>
	</div>
</section>