<?php
/*

Template Name: Executive Leadership Template

*/
?>
<?php
	$executive_leadership_page_banner_image = get_field('executive_leadership_page_banner_image');
	$executive_leadership_page_banner_first_title = get_field('executive_leadership_page_banner_first_title');
	$executive_leadership_page_banner_second_title = get_field('executive_leadership_page_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $executive_leadership_page_banner_image['url']; ?>);">
	<div class="banner-layout">
		<div class="title container" data-aos="fade-up" data-aos-duration="1500">
				<h5><?php echo $executive_leadership_page_banner_first_title; ?></h5>
				<h2><?php echo $executive_leadership_page_banner_second_title; ?></h2>
		</div>
	</div>
</section>

<?php
	$executive_leadership_page_executive_image = get_field('executive_leadership_page_executive_image');
?>
<section class="leadership-page-sec">
	<div class="container">
		<div class="full-block">
			<div class="left-block">
				<img src="<?php echo $executive_leadership_page_executive_image['url']; ?>" alt="">
			</div>
			<div class="right-block">
				<?php if( have_rows('executive_leadership_page_executives') ): ?>
				<?php while( have_rows('executive_leadership_page_executives') ): the_row(); 
				$name = get_sub_field('name');
				$designation = get_sub_field('designation');
				$email = get_sub_field('email');
				?>
				<div class="single">
					<div class="name">
						<h3><?php echo $name; ?></h3>
					</div>
					<div class="designation">
						<span><?php echo $designation; ?></span>
					</div>
					<div class="link-part">
						<a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a>
					</div>
				</div>
				<?php endwhile; ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>