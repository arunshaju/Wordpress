 <?php
/*

Template Name: Our Solutions Template

*/
?>
<?php
	$our_solutions_banner_image = get_field('our_solutions_banner_image');
	$our_solutions_banner_first_title = get_field('our_solutions_banner_first_title');
	$our_solutions_banner_second_title = get_field('our_solutions_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $our_solutions_banner_image['sizes']['home-banner']; ?>)">
	<div class="banner-layout">
	  <div class="title container" data-aos="fade-up" data-aos-duration="1500">
	      <h5><?php echo $our_solutions_banner_first_title; ?></h5>
	      <h2><?php echo $our_solutions_banner_second_title; ?></h2>
	  </div>
	</div>
</section>
<?php
	$our_solutions_empowering_first_title = get_field('our_solutions_empowering_first_title');
	$our_solutions_empowering_second_title = get_field('our_solutions_empowering_second_title');
	$our_solutions_empowering_content = get_field('our_solutions_empowering_content');
?>
<section class="empowering-part" data-aos="fade-up" data-aos-duration="1500">
	<div class="container">
	  <div class="content-part">
	    <div class="title">
	      <h5><?php echo $our_solutions_empowering_first_title; ?></h5>
	      <h2><?php echo $our_solutions_empowering_second_title; ?></h2>
	    </div>
	    <div class="para-content">
	      <p><?php echo $our_solutions_empowering_content; ?></p>
	    </div>
	  </div>
	</div>
</section>
<section class="our-solution-grid-part">
	<div class="container">
	  <div class="card-pats">
	  	<?php if( have_rows('our_solutions_main_solutions') ): ?>
  		<?php while( have_rows('our_solutions_main_solutions') ): the_row(); 
			$image = get_sub_field('image');
			$title = get_sub_field('title');
			$content = get_sub_field('content');
			$cta_text = get_sub_field('cta_text');
			$cta_link = get_sub_field('cta_link');
		?>
	    <div class="single-card" data-aos="fade-up" data-aos-duration="1500">
	      <div class="img-part">
	        <img src="<?php echo $image['sizes']['our-solution-grid'] ?>" alt="">
	      </div>
	      <div class="content-part">
	        <div class="title-and-content">
	          <h3><?php echo $title; ?></h3>
	          <p><?php echo $content; ?></p>
	          <a href="<?php echo $cta_link; ?>" class="learn-more"><?php echo $cta_text; ?><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
	        </div>
	      </div>
	    </div>
		<?php endwhile; ?>
		<?php endif; ?>
	  </div>
	</div>
</section>
<?php
	$our_solutions_news_and_events_title = get_field('our_solutions_news_and_events_title');
	$our_solutions_news_and_events_image = get_field('our_solutions_news_and_events_image');
	$our_solutions_main_event_title = get_field('our_solutions_main_event_title');
	$our_solutions_news_and_events_date = get_field('our_solutions_news_and_events_date');
	$our_solutions_news_and_events_cta_text = get_field('our_solutions_news_and_events_cta_text');
	$our_solutions_news_and_events_cta_link = get_field('our_solutions_news_and_events_cta_link');
?>
<section class="related-news">
	<div class="container">
	  <div class="title-part" data-aos="fade-up" data-aos-duration="1500">
	    <h4><?php $our_solutions_news_and_events_title; ?></h4>
	  </div>
	  <div class="news-part-main" data-aos="fade-up" data-aos-duration="1500">
	    <div class="img-part">
	      <img src="<?php echo $our_solutions_news_and_events_image['sizes']['our_solutions_news_and_events'] ?>" alt="">
	    </div>
	    <div class="content-part">
	      <h3><?php echo $our_solutions_main_event_title; ?></h3>
	      <div class="date-part">
	        <span><?php echo $our_solutions_news_and_events_date; ?></span>
	      </div>
	      <div class="link-part">
	        <a href="<?php echo $our_solutions_news_and_events_cta_link; ?>" class="learn-more"><?php echo $our_solutions_news_and_events_cta_text; ?><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
	      </div>
	    </div>
	  </div>
	  <div class="news-part" data-aos="fade-up" data-aos-duration="1500">
	    <div class="showslide">
	    	
	      <?php  
            $number = 1;
            $news_args = array(

              'post_type' => 'news',

              'post_status' => 'publish',

              'posts_per_page' => -1

            );
            $news_query = new WP_Query( $news_args );
            if ( $news_query->have_posts() ):
            while ( $news_query->have_posts() ) : $news_query->the_post();
          ?>
          <?php 
          	$front_display_content = get_field('front_display_content');
          	$news_inner_date = get_field('news_inner_date');
          ?>
	      <div class="single-events">
	        <a href="<?php the_permalink(); ?>">
	          <h5><?php echo $news_inner_date; ?></h5>
	          <h2><?php echo the_title(); ?></h2>
	          <p><?php echo $front_display_content; ?></p>
	        </a>
	      </div>
	      <?php
            endwhile;
            endif;
            wp_reset_postdata();
          ?>
	      <!-- <div class="single-events">
	        <a href="#">
	          <h5>10 October 2019</h5>
	          <h2>Our UAE branch reaches new heights</h2>
	          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</p>
	        </a>
	      </div>
	      <div class="single-events">
	        <a href="#">
	          <h5>10 October 2019</h5>
	          <h2>Our UAE branch reaches new heights</h2>
	          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</p>
	        </a>
	      </div>
	      <div class="single-events">
	        <a href="#">
	          <h5>10 October 2019</h5>
	          <h2>Our UAE branch reaches new heights</h2>
	          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</p>
	        </a>
	      </div>
	      <div class="single-events">
	        <a href="#">
	          <h5>10 October 2019</h5>
	          <h2>Our UAE branch reaches new heights</h2>
	          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</p>
	        </a>
	      </div>
	      <div class="single-events">
	        <a href="#">
	          <h5>10 October 2019</h5>
	          <h2>Our UAE branch reaches new heights</h2>
	          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</p>
	        </a>
	      </div> -->
	    </div>
	    <ul>
	        <li class="prev-show"><a href="JavaScript:Void(0);"><i class="fa fa-angle-left" aria-hidden="true"></i></a></i></li>
	        <li class="next-show"><a href="JavaScript:Void(0);"><i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
	    </ul>
	  </div>
	</div>
</section>