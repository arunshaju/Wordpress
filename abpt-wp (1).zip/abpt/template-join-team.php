<?php
/*

Template Name: Join Page Template

*/
?>
<?php
	$join_banner_image = get_field('join_banner_image');
	$join_banner_first_title = get_field('join_banner_first_title');
	$join_banner_second_title = get_field('join_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $join_banner_image['url']; ?>);">
  <div class="banner-layout">
    <div class="title container" data-aos="fade-up" data-aos-duration="1500">
        <h5><?php echo $join_banner_first_title; ?></h5>
        <h2><?php echo $join_banner_second_title; ?></h2>
    </div>
  </div>
</section>
<?php
	$join_left_block_first_title = get_field('join_left_block_first_title');
	$join_left_block_second_title = get_field('join_left_block_second_title');
	$join_left_block_content = get_field('join_left_block_content');
	$join_left_block_cta_text = get_field('join_left_block_cta_text');
	$join_left_block_cta_link = get_field('join_left_block_cta_link');
?>
<section class="join-full-part">
	<div class="container">
		<div class="full-block">
			<div class="left-block">
				<div class="title">
					<h5><?php echo $join_left_block_first_title; ?></h5>
					<h2><?php echo $join_left_block_second_title; ?></h2>
				</div>
				<div class="content">
					<p><?php echo $join_left_block_content; ?></p>
				</div>
				<!-- <div class="link-part">
					<a href="<?php //echo $join_left_block_cta_link; ?>" class="learn-more"><?php //echo $join_left_block_cta_text; ?><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
				</div> -->
			</div>
			<?php
			$join_right_block_title = get_field('join_right_block_title');
			$join_right_form_part = get_field('join_right_form_part');
			$join_right_form_part_arabic = get_field('join_right_form_part_arabic');
			?>
			<div class="right-block">
				<div class="right-block-inner">
					<div class="title">
						<h5><?php echo $join_right_block_title; ?></h5>
					</div>
					<?php if(get_bloginfo('language')=='en-US') 
					{ ?>
					<?php echo $join_right_form_part; ?>
					<?php } else { ?>
					<?php echo $join_right_form_part_arabic; ?>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
</section>