<?php 
//Ajax Functions

add_action('wp_ajax_my_action','data_fetch');
add_action('wp_ajax_nopriv_my_action','data_fetch');
function data_fetch(){
	$args = array(
		'post_type'			=> 'books',
		'posts_per_page' 	=> -1,
	);

	$the_query = new WP_Query($args);
	// The Loop
	if ( $the_query->have_posts() ) {
		
		while ( $the_query->have_posts() ) {
			$the_query->the_post();
			echo '<h3>' . get_the_title() . '</h3>';
			echo '<p>' . get_the_excerpt() . '</p>';
		}
		echo '</br>';
		
		/* Restore original Post Data */
		wp_reset_postdata();
	} else {
		echo 'no posts found';
	}
	die();
}

// Post title Like
add_filter( 'posts_where', 'title_like_posts_where', 10, 2 );
function title_like_posts_where( $where, &$wp_query ) {
    global $wpdb;
    if ( $post_title_like = $wp_query->get( 'post_title_like' ) ) {
        $where .= ' AND ' . $wpdb->posts . '.post_title LIKE \'' . esc_sql( $wpdb->esc_like($post_title_like ) ) . '%\'';
    }
    return $where;
}


add_action('wp_ajax_search_result','data_search');
add_action('wp_ajax_nopriv_search_result','data_search');
function data_search(){

	$searhFor = $_POST['searchFor'];
	$filterby = $_POST['showcategory'];
	$sortResults = $_POST['order_by'];
	
	$args = array(
		//'s' 				=>	$searhFor,
	  	'post_title_like'	=>	$searhFor,
		'post_type'			=> 	'books',
		'posts_per_page' 	=> 	-1,
		'order'				=> 	$sortResults,
		'tax_query' 		=> 	array(
		    array(
		    	'taxonomy'		=> 'topics',
		    	'field'			=> 'id',
		    	'terms' 		=> $filterby
		     )
	  	),
	  	/*
	  	'meta_query' => array(
            array(
                'key' => array('title'),
                'value' => $searhFor,
                'compare' => 'LIKE'
            )
        )
        */
	);

	$the_query = new WP_Query($args);
	// The Loop
	if ( $the_query->have_posts() ) {
		
		while ( $the_query->have_posts() ) {
			$the_query->the_post();
			echo '<h3>' . get_the_title() . '</h3>';
			echo '<p>' . get_the_excerpt() . '</p>';
		}
		echo '</br>';
		
		/* Restore original Post Data */
		wp_reset_postdata();
	} else {
		echo 'no posts found';
	}
	die();
}
