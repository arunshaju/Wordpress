<?php

/**

* Custom functions

*/



if ( function_exists( 'add_theme_support' ) ) { 
     add_theme_support( 'post-thumbnails' );
     set_post_thumbnail_size( 300, 324, true ); // default Post Thumbnail dimensions (cropped)
     add_image_size( 'gallery', 1024, 567, true );
     add_image_size( 'gallery-thumb', 300, 165, true );
     add_image_size( 'home-banner', 1920, 784, true );
     add_image_size( 'home-about-image', 689, 493, true );
     add_image_size( 'home_solutions_first_row_image', 960, 443, true );
     add_image_size( 'home_solutions_telecommunication_image', 960, 443, true );
     add_image_size( 'home_solutions_transmission_image', 479, 486, true );
     add_image_size( 'home-all-solutions', 960, 486, true );
     add_image_size( 'home_egypt_block_image', 248, 458, true );
     add_image_size( 'home_our_facilities_right_image', 828, 1426, true );
     add_image_size( 'our-solution-grid', 800, 428, true );
     add_image_size( 'our_solutions_news_and_events', 1173, 589, true );
     add_image_size( 'each_products', 660, 353, true );
     add_image_size( 'each_products_second', 437, 350, true );
     add_image_size( 'entities-img', 312, 208, true );


}



wp_enqueue_style( 'dashicons' );



// Highlihgt Custom posttype Menu item

function remove_parent_classes($class)

{

	return ($class == 'active' || $class == 'active' || $class == 'active') ? FALSE : TRUE;

}

function add_class_to_wp_nav_menu($classes)

{

     switch (get_post_type())

     {

     	case 'units':

     		// we're viewing a custom post type, so remove the 'current_page_xxx and current-menu-item' from all menu items.

     		$classes = array_filter($classes, "remove_parent_classes");



     		// add the current page class to a specific menu item (replace ###).

     		if (in_array('menu-business-units', $classes))

     		{

				$classes[] = 'active';

			}

     		break;

     }

	return $classes;

}

add_filter('nav_menu_css_class', 'add_class_to_wp_nav_menu');





