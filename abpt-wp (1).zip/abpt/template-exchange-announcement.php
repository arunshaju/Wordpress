<?php
/*

Template Name: Exchange Announcement Page Template

*/
?>
<?php
$news_banner_image = get_field('news_banner_image');
$news_banner_first_title = get_field('news_banner_first_title');
$news_banner_second_title = get_field('news_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $news_banner_image['url']; ?>);">
  <div class="banner-layout">
    <div class="title container" data-aos="fade-up" data-aos-duration="1500">
        <h5><?php echo $news_banner_first_title; ?></h5>
        <h2><?php echo $news_banner_second_title; ?></h2>
    </div>
  </div>
</section>
<section class="press-release-main-sec">
	<div class="container">
			<?php  
	      $number = 1;
	      $exchange_args = array(

	        'post_type' => 'exchange',

	        'post_status' => 'publish',

	        'posts_per_page' => -1

	      );
	      $exchange_query = new WP_Query( $exchange_args );
	      if ( $exchange_query->have_posts() ):
	      while ( $exchange_query->have_posts() ) : $exchange_query->the_post();
	      ?>
	      <?php
	      $news_inner_date = get_field('news_inner_date');
	      ?>
		<div class="single">
			<a href="<?php the_permalink(); ?>">
				<div class="title">
					<span><?php echo $news_inner_date; ?></span>
					<h3><?php echo the_title(); ?></h3>
					<i class="fa fa-angle-right" aria-hidden="true"></i>
				</div>
			</a>
		</div>
		<?php 
		endwhile; 
		endif; 
		wp_reset_postdata();
		?>
	</div>
</section>