<?php
/*

Template Name: About Template

*/
?>
<?php
$about_banner_image = get_field('about_banner_image');
$about_banner_first_title = get_field('about_banner_first_title');
$about_banner_second_title = get_field('about_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $about_banner_image['url']; ?>);">
  <div class="banner-layout">
    <div class="title container" data-aos="fade-up" data-aos-duration="1500">
        <h5><?php echo $about_banner_first_title;?></h5>
        <h2><?php echo $about_banner_second_title; ?></h2>
    </div>
  </div>
</section>
<?php
$about_leadership_first_title = get_field('about_leadership_first_title');
$about_leadership_second_title = get_field('about_leadership_second_title');
?>
<section class="empowering-part about-empowering" data-aos="fade-up" data-aos-duration="1500">
  <div class="container">
    <div class="content-part">
      <div class="title">
        <h5><?php echo $about_leadership_first_title; ?></h5>
        <h2><?php echo $about_leadership_second_title; ?></h2>
      </div>
			<div class="about-details">
				<?php if( have_rows('about_leadership_each_leadership') ): ?>
				<?php while( have_rows('about_leadership_each_leadership') ): the_row(); 
				$name = get_sub_field('name');
				$designation = get_sub_field('designation');
				?>
				<div class="single">
					<h3><?php echo $name; ?></h3>
					<h6><?php echo $designation; ?></h6>
				</div>
				<?php endwhile; ?>
				<?php endif; ?>
			</div>
    </div>
  </div>
</section>
<?php
$about_history_first_title = get_field('about_history_first_title');
$about_history_second_title = get_field('about_history_second_title');
?>
<section class="our-history">
	<div class="container">
		<h5><?php echo $about_history_first_title; ?></h5>
		<h2><?php echo $about_history_second_title; ?></h2>
		<div class="full-history">
			<div class="abt-history">
				<?php if( have_rows('about_each_history') ): ?>
				<?php while( have_rows('about_each_history') ): the_row(); 
				$year = get_sub_field('year');
				$content = get_sub_field('content');
				?>
				<div class="single">
					<h2><?php echo $year; ?></h2>
					<span><?php echo $content; ?></span>
				</div>
				<?php endwhile; ?>
				<?php endif; ?>
			</div>
			<ul>
				<li class="prev-hist"><a href="JavaScript:Void(0);"><i class="fa fa-angle-left" aria-hidden="true"></i></a></i></li>
          <li class="next-hist"><a href="JavaScript:Void(0);"><i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
			</ul>
		</div>
  </div>
  <?php
  $about_history_cta_text = get_field('about_history_cta_text');
  $about_history_cta_link = get_field('about_history_cta_link');
  ?>
  <div class="link-part">
    <div class="container">
      <a href="<?php echo $about_history_cta_link; ?>" class="learn-more"><?php echo $about_history_cta_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
    </div>
  </div>
</section>
<?php
$about_our_strengths_first_title = get_field('about_our_strengths_first_title');
$about_our_strengths_second_title = get_field('about_our_strengths_second_title');
?>
<section class="our-strengths">
  <div class="container">
    <h5><?php echo $about_our_strengths_first_title; ?></h5>
    <h2><?php echo $about_our_strengths_second_title; ?></h2>
    <div class="box-part">
    	<?php if( have_rows('about_our_strengths_each_strengths') ): ?>
			<?php while( have_rows('about_our_strengths_each_strengths') ): the_row(); 
			$title = get_sub_field('title');
			$content = get_sub_field('content');
			?>
      <div class="single-block">
        <h3><?php echo $title; ?></h3>
        <p><?php echo $content; ?></p>
      </div>
    	<?php endwhile; ?>
    	<?php endif; ?>
    </div>
    <?php
    $about_our_strengths_cta_text = get_field('about_our_strengths_cta_text');
    $about_our_strengths_cta_link = get_field('about_our_strengths_cta_link');
    ?>
    <div class="link-part">
      <a href="<?php echo $about_our_strengths_cta_link; ?>" class="learn-more"><?php echo $about_our_strengths_cta_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
    </div>
  </div>
</section>
<?php
$about_core_values_image = get_field('about_core_values_image');
?>
<section class="core-vision" style="background-image: url(<?php echo $about_core_values_image['url']; ?>);">
  <div class="container">
    <div class="full-block">
      <?php if( have_rows('about_each_core_values') ): ?>
      <?php while( have_rows('about_each_core_values') ): the_row(); 
      $first_title = get_sub_field('first_title');
      $second_title = get_sub_field('second_title');
      $content = get_sub_field('content');
      ?>
      <div class="single">
        <h5><?php echo $first_title; ?></h5>
        <h2><?php echo $second_title; ?></h2>
        <p><?php echo $content; ?></p>
      </div>
      <?php
      endwhile;
      endif;
      ?>
    </div>
  </div>
</section>
<?php
$about_testimonials_first_title = get_field('about_testimonials_first_title');
$about_testimonials_second_title = get_field('about_testimonials_second_title');
?>
<section class="clients-testimonials">
  <div class="container">
    <h5><?php echo $about_testimonials_first_title; ?></h5>  
    <h2><?php echo $about_testimonials_second_title; ?></h2>
    <div class="testimonial-block">
      <div class="testimonials">
        <?php if( have_rows('about_each_testimonials') ): ?>
        <?php while( have_rows('about_each_testimonials') ): the_row(); 
        $image = get_sub_field('image');
        $content = get_sub_field('content');
        $industry = get_sub_field('industry');
        ?>
        <div class="single">
          <div class="logo-part">
            <img src="<?php echo $image['url'] ?>" alt="">
          </div>
          <div class="content-part">
            <p>"<?php echo $content; ?>"</p>
          </div>
          <div class="name-part">
            <span><?php echo $industry; ?></span>
          </div>
        </div>
        <?php endwhile; ?>
        <?php endif ?>
      </div>
      <ul>
        <li class="prev-test"><a href="JavaScript:Void(0);"><i class="fa fa-angle-left" aria-hidden="true"></i></a></i></li>
        <li class="next-test"><a href="JavaScript:Void(0);"><i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
      </ul>
    </div>
  </div>
</section>
<?php
$about_our_clients_first_title = get_field('about_our_clients_first_title');
$about_our_clients_second_title = get_field('about_our_clients_second_title');
?>
<section class="about-our-clients">
  <div class="container">
    <h5><?php echo $about_our_clients_first_title; ?></h5>
    <h2><?php echo $about_our_clients_second_title; ?></h2>
    <div class="full-logo-part">
      <?php if( have_rows('about_our_clients_client_logos') ): ?>
      <?php while( have_rows('about_our_clients_client_logos') ): the_row(); 
      $image = get_sub_field('image');
      ?>
      <div class="logo">
        <img src="<?php echo $image['url']; ?>" alt="">
      </div>
      <?php endwhile; ?>
      <?php endif; ?>
    </div>
  </div>
</section>