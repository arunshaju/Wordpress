<?php
/*

Template Name: Financials Page Template

*/
?>
<?php
$news_banner_image = get_field('news_banner_image');
$news_banner_first_title = get_field('news_banner_first_title');
$news_banner_second_title = get_field('news_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $news_banner_image['url']; ?>);">
  <div class="banner-layout">
    <div class="title container" data-aos="fade-up" data-aos-duration="1500">
        <h5><?php echo $news_banner_first_title; ?></h5>
        <h2><?php echo $news_banner_second_title; ?></h2>
    </div>
  </div>
</section>
<section class="press-release-main-sec">
	<div class="container">
		<?php if( have_rows('abpt_financials_template_block') ): ?>
		<?php while( have_rows('abpt_financials_template_block') ): the_row(); 
		$date = get_sub_field('date');
		$content = get_sub_field('content');
		$link = get_sub_field('link');
		?>
		<div class="single">
			<a href="<?php echo $link; ?>">
				<div class="title">
					<span><?php echo $date; ?></span>
					<h3><?php echo $content; ?></h3>
					<i class="fa fa-download" aria-hidden="true"></i>
				</div>
			</a>
		</div>
		<?php endwhile; ?>
		<?php endif; ?>
		
	</div>
</section>