<?php
	$news_inner_banner_image = get_field('news_inner_banner_image');
	$news_inner_banner_first_title = get_field('news_inner_banner_first_title');
	$news_inner_banner_second_title = get_field('news_inner_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $news_inner_banner_image['url']; ?>);">
	<div class="banner-layout">
		<div class="title container" data-aos="fade-up" data-aos-duration="1500">
				<h5><?php echo $news_inner_banner_first_title; ?></h5>
				<h2><?php echo $news_inner_banner_second_title; ?></h2>
		</div>
	</div>
</section>
<?php
$news_inner_date = get_field('news_inner_date');
$news_content = get_field('news_content');
?>
<section class="strength-content-part">
	<div class="container">
		<div class="news-inner-full-block">
			<div class="left-block">
				<div class="date-part-news-inner">
					<span><?php echo $news_inner_date; ?></span>
				</div>
				<?php echo $news_content; ?>
			</div>
			<div class="right-block">
				<div class="right-block-inner">
					<h4>Recent News</h4>
					<ul>
					  <?php  
				      $number = 1;
				      $news_args = array(

				        'post_type' => 'news',

				        'post_status' => 'publish',

				        'posts_per_page' => 5

				      );
				      $news_query = new WP_Query( $news_args );
				      if ( $news_query->have_posts() ):
				      while ( $news_query->have_posts() ) : $news_query->the_post();
				      ?>
						<li><a href="<?php the_permalink(); ?>"><?php echo the_title(); ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
					<?php 
					endwhile; 
					endif; 
					wp_reset_postdata();
					?>
				</div>
			</div>
		</div>
	</div>
</section>