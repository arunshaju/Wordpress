<?php
/*

Template Name: Press Release Page Template

*/
?>
<?php
$news_banner_image = get_field('news_banner_image');
$news_banner_first_title = get_field('news_banner_first_title');
$news_banner_second_title = get_field('news_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $news_banner_image['url']; ?>);">
  <div class="banner-layout">
    <div class="title container" data-aos="fade-up" data-aos-duration="1500">
        <h5><?php echo $news_banner_first_title; ?></h5>
        <h2><?php echo $news_banner_second_title; ?></h2>
    </div>
  </div>
</section>
<section class="press-release-main-sec">
	<div class="container">
		<select class="event-type-select press-select-part">
      <?php
			$select_year_translation = get_field('select_year_translation','option')
			?>
      <option value="all"><?php echo $select_year_translation; ?></option>
      <?php if( have_rows('press_release_filters', 'option') ): ?>
    	<?php while( have_rows('press_release_filters', 'option') ): the_row(); 
    		$year = get_sub_field('year');
    		$slug = get_sub_field('slug');
    	?>
      <option value="<?php echo $slug; ?>"><?php echo $year; ?></option>
    	<?php endwhile; ?>
    	<?php endif; ?>
      <!-- <option value="2018">2018</option>
      <option value="2017">2017</option>
      <option value="2016">2016</option>
      <option value="2015">2015</option>
      <option value="2014">2014</option> -->
  	</select>
			<?php  
	      $number = 1;
	      $press_args = array(

	        'post_type' => 'press-release',

	        'post_status' => 'publish',

	        'posts_per_page' => -1

	      );
	      $press_query = new WP_Query( $press_args );
	      if ( $press_query->have_posts() ):
	      while ( $press_query->have_posts() ) : $press_query->the_post();
				$press_select_category = get_the_terms( $post->ID, 'presstax' );
        $designation = get_the_terms( $post->ID, 'presstax' );
				foreach($press_select_category as $press_select_category) {
				$cat_type = $press_select_category->slug;
				}
      ?>
      <?php
      $news_inner_date = get_field('news_inner_date');
      ?>
		<div class="single news-cat" data-eventtype="<?php echo $cat_type; ?>">
			<a href="<?php the_permalink(); ?>">
				<div class="title">
					<span><?php echo $news_inner_date; ?></span>
					<h3><?php echo the_title(); ?></h3>
					<i class="fa fa-angle-right" aria-hidden="true"></i>
				</div>
			</a>
		</div>
		<?php 
		endwhile; 
		endif; 
		wp_reset_postdata();
		?>
		<!-- <div class="single">
			<a href="#">
				<div class="title">
					<span>10 Oct 2019</span>
					<h3>Lorem Ipsum is simply dummy text</h3>
					<i class="fa fa-angle-right" aria-hidden="true"></i>
				</div>
			</a>
		</div>
		<div class="single">
			<a href="#">
				<div class="title">
					<span>10 Oct 2019</span>
					<h3>Lorem Ipsum is simply dummy text</h3>
					<i class="fa fa-angle-right" aria-hidden="true"></i>
				</div>
			</a>
		</div>
		<div class="single">
			<a href="#">
				<div class="title">
					<span>10 Oct 2019</span>
					<h3>Lorem Ipsum is simply dummy text</h3>
					<i class="fa fa-angle-right" aria-hidden="true"></i>
				</div>
			</a>
		</div>
		<div class="single">
			<a href="#">
				<div class="title">
					<span>10 Oct 2019</span>
					<h3>Lorem Ipsum is simply dummy text</h3>
					<i class="fa fa-angle-right" aria-hidden="true"></i>
				</div>
			</a>
		</div>
		<div class="single">
			<a href="#">
				<div class="title">
					<span>10 Oct 2019</span>
					<h3>Lorem Ipsum is simply dummy text</h3>
					<i class="fa fa-angle-right" aria-hidden="true"></i>
				</div>
			</a>
		</div> -->
	</div>
</section>