 <?php
/*

Template Name: Home Page Template

*/
?>

<?php
$home_banner_image = get_field('home_banner_image');
?>
<section class="banner-part" style="background-image: url(<?php echo $home_banner_image['sizes']['home-banner']; ?>)">

  <div class="main-banner-bg">

    <div class="container">
      <?php 
        $home_banner_first_title = get_field('home_banner_first_title');
        $home_banner_second_title = get_field('home_banner_second_title');
      ?>
      <div class="title-part" data-aos="fade-up" data-aos-duration="1500">

        <h5><?php echo $home_banner_first_title; ?></h5>

        <h2><?php echo $home_banner_second_title; ?></h2>

      </div>

      <div class="banner-news-events">

        <div class="each-events">

          <div class="autoplay">
          <?php  
          $number = 1;
          $news_args = array(

            'post_type' => 'news',

            'post_status' => 'publish',

            'posts_per_page' => -1

          );
          $news_query = new WP_Query( $news_args );
          if ( $news_query->have_posts() ):
          while ( $news_query->have_posts() ) : $news_query->the_post();
          ?>
            <div class="single-events">

              <a href="<?php the_permalink(); ?>">

                <h5>News & Events</h5>

                <h4><?php echo the_title(); ?></h4>

              </a>

            </div>
          <?php
          endwhile;
          endif;
          wp_reset_postdata();
          ?>
          </div>

        </div>

      </div>

    </div>

  </div>

</section>
<?php
  $home_about_image = get_field('home_about_image');
  $home_about_first_title = get_field('home_about_first_title');
  $home_about_second_title = get_field('home_about_second_title');
  $home_about_content = get_field('home_about_content');
  $home_about_cta_text = get_field('home_about_cta_text');
  $home_about_cta_link = get_field('home_about_cta_link');
?>
<section class="home-about">

  <div class="container">

    <div class="about-full-width">

      <div class="left-img" data-aos="fade-up" data-aos-duration="1500">

        <img src="<?php echo $home_about_image['sizes']['home-about-image'];?>" alt="">

      </div>

      <div class="right-content" data-aos="fade-up" data-aos-duration="1500">

        <div class="title-part">

          <h5><?php echo $home_about_first_title; ?></h5>

          <h2><?php echo $home_about_second_title; ?></h2>

        </div>

        <div class="content-part">
          <?php echo $home_about_content; ?>
          <a href="<?php echo $home_about_cta_link; ?>" class="learn-more"><?php echo $home_about_cta_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i>

          </a>

        </div>

      </div>

    </div>

  </div>

</section>
<section class="our-departments">
  <?php
    $home_solutions_first_row_image = get_field('home_solutions_first_row_image');
    $home_solutions_first_row_title = get_field('home_solutions_first_row_title');
    $home_solutions_first_row_content = get_field('home_solutions_first_row_content');
    $home_solutions_first_row_cta_text = get_field('home_solutions_first_row_cta_text');
    $home_solutions_first_row_cta_link = get_field('home_solutions_first_row_cta_link');
  ?>
  <div class="first-row-part">

    <div class="full-part">

      <div class="left-img-part" data-aos="fade-up" data-aos-duration="1500">

        <img src="<?php echo $home_solutions_first_row_image['sizes']['home_solutions_first_row_image'] ?>" alt="">

      </div>

      <div class="content-right" data-aos="fade-up" data-aos-duration="1500">

        <div class="title">

          <h3><?php echo $home_solutions_first_row_title; ?></h3>

        </div>

        <div class="content">

          <p><?php echo $home_solutions_first_row_content; ?></p>

          <a href="<?php $home_solutions_first_row_cta_link; ?>" class="learn-more"><?php echo $home_solutions_first_row_cta_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i>

          </a>

        </div>

      </div>

    </div>

  </div>
  <?php
  $home_solutions_second_row_telecommunication_title = get_field('home_solutions_second_row_telecommunication_title');
  $home_solutions_telecommunication_content = get_field('home_solutions_telecommunication_content');
  $home_solutions_telecommunication_cta = get_field('home_solutions_telecommunication_cta');
  $home_solutions_telecommunication_cta_link = get_field('home_solutions_telecommunication_cta_link');
  $home_solutions_telecommunication_image = get_field('home_solutions_telecommunication_image');
  $home_solutions_transmission_title = get_field('home_solutions_transmission_title');
  $home_solutions_transmission_content = get_field('home_solutions_transmission_content');
  $home_solutions_transmission_cta_text = get_field('home_solutions_transmission_cta_text');
  $home_solutions_transmission_cta_link = get_field('home_solutions_transmission_cta_link');
  $home_solutions_transmission_image = get_field('home_solutions_transmission_image');
  ?>
  <div class="second-row-part">

    <div class="tele-content-part" data-aos="fade-up" data-aos-duration="1500">

      <div class="title">

        <h3><?php echo $home_solutions_second_row_telecommunication_title; ?></h3>

      </div>

      <div class="content">

        <p><?php echo $home_solutions_telecommunication_content; ?></p>

        <a href="<?php echo $home_solutions_telecommunication_cta_link ?>" class="learn-more"><?php echo $home_solutions_telecommunication_cta; ?><i class="fa fa-angle-right" aria-hidden="true"></i>

        </a>

      </div>

    </div>

    <div class="tele-img-part" data-aos="fade-up" data-aos-duration="1500">

      <img src="<?php echo $home_solutions_telecommunication_image['sizes']['home_solutions_telecommunication_image']; ?>" alt="">

    </div>

    <div class="distribution-content" data-aos="fade-up" data-aos-duration="1500">

      <div class="title">

        <h3><?php echo $home_solutions_transmission_title; ?></h3>

      </div>

      <div class="content">

        <p><?php echo $home_solutions_transmission_content; ?></p>

        <a href="<?php echo $home_solutions_transmission_cta_link; ?>" class="learn-more"><?php echo $home_solutions_transmission_cta_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i>

        </a>

      </div>

    </div>

    <div class="distribution-img" data-aos="fade-up" data-aos-duration="1500">

      <img src="<?php echo $home_solutions_transmission_image['sizes']['home_solutions_transmission_image']; ?>" alt="">

    </div>

  </div>
  <?php
    $home_solutions_renewable_energy_image = get_field('home_solutions_renewable_energy_image');
    $home_solutions_renewable_energy_title = get_field('home_solutions_renewable_energy_title');
    $home_solutions_renewable_energy_content = get_field('home_solutions_renewable_energy_content');
    $renewable_energy_cta_text = get_field('renewable_energy_cta_text');
    $renewable_energy_cta_link = get_field('renewable_energy_cta_link');
    $home_solutions_see_all_text = get_field('home_solutions_see_all_text');
    $home_solutions_see_all_text_url = get_field('home_solutions_see_all_text_url');
    $home_solutions_see_all_background_image = get_field('home_solutions_see_all_background_image');
  ?>
  <div class="third-row-part">

    <div class="renewable-img" data-aos="fade-up" data-aos-duration="1500">

      <img src="<?php echo $home_solutions_renewable_energy_image['sizes']['home_solutions_transmission_image']; ?>" alt="Solar">

    </div>

    <div class="renewable-content" data-aos="fade-up" data-aos-duration="1500">

      <div class="title">

        <h3><?php echo $home_solutions_renewable_energy_title; ?></h3>

      </div>

      <div class="content">

        <p><?php echo $home_solutions_renewable_energy_content; ?></p>

        <a href="<?php echo $renewable_energy_cta_link; ?>" class="learn-more"><?php echo $renewable_energy_cta_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i>

        </a>

      </div>

    </div>

    <div class="all-solutions" data-aos="fade-up" data-aos-duration="1500" style="background-image: url(<?php echo $home_solutions_see_all_background_image['sizes']['home-all-solutions']; ?>)">

      <div class="all-sol-btn">

        <a href="<?php echo $home_solutions_see_all_text_url; ?>" class="learn-more"><?php echo $home_solutions_see_all_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i>

        </a>

      </div>

    </div>

  </div>

</section>
<?php
  $home_news_and_events_main_title = get_field('home_news_and_events_main_title');
  $home_egypt_block_title = get_field('home_egypt_block_title');
  $home_egypt_block_date = get_field('home_egypt_block_date');
  $egypt_block_cta_text = get_field('egypt_block_cta_text');
  $home_egypt_block_url = get_field('home_egypt_block_url');
  $home_egypt_block_image = get_field('home_egypt_block_image');
  $home_uae_block_title = get_field('home_uae_block_title');
  $home_uae_block_date = get_field('home_uae_block_date');
  $uae_block_cta_text = get_field('uae_block_cta_text');
  $home_uae_block_url = get_field('home_uae_block_url');
  $home_uae__block_image = get_field('home_uae__block_image');
  $home_see_all_news_and_events_text = get_field('home_see_all_news_and_events_text');
  $home_all_news_and_events_link = get_field('home_all_news_and_events_link');
?>
<section class="news-and-events">

  <div class="container">

    <div class="title-part" data-aos="fade-up" data-aos-duration="2000">

      <h4><?php echo $home_news_and_events_main_title; ?></h4>

    </div>

    <div class="full-branch-part">

      <div class="first-branch each-part" data-aos="fade-up" data-aos-duration="2000">

        <div class="content-part">

            <h3><?php echo $home_egypt_block_title; ?></h3>

            <div class="date-part">

              <span><?php echo $home_egypt_block_date; ?></span>

            </div>

            <div class="link-part">

              <a href="<?php echo $home_egypt_block_url; ?>" class="learn-more"><?php echo $egypt_block_cta_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i></a>

            </div>

        </div>

        <div class="img-part">

          <img src="<?php echo $home_egypt_block_image['sizes']['home_egypt_block_image']; ?>" alt="">

        </div>

      </div>

      <div class="second-branch each-part" data-aos="fade-up" data-aos-duration="2000">

          <div class="content-part">

            <h3><?php echo $home_uae_block_title; ?></h3>

            <div class="date-part">

              <span><?php echo $home_uae_block_date; ?></span>

            </div>

            <div class="link-part">

              <a href="<?php echo $home_uae_block_url; ?>" class="learn-more"><?php echo $uae_block_cta_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i></a>

            </div>

          </div>

          <div class="img-part">

            <img src="<?php echo $home_uae__block_image['sizes']['home_egypt_block_image']; ?>" alt="">

          </div>

      </div>

      <div class="third-branch each-part" data-aos="fade-up" data-aos-duration="2000">
      
        <div class="each-events">
          <?php  
            $number = 1;
            $news_args = array(

              'post_type' => 'news',

              'post_status' => 'publish',

              'posts_per_page' => 4

            );
            $news_query = new WP_Query( $news_args );
            if ( $news_query->have_posts() ):
            while ( $news_query->have_posts() ) : $news_query->the_post();
          ?>
          <div class="single-events">

            <a href="<?php the_permalink(); ?>">

              <div class="title">

                <span>News & Events</span>

              </div>

              <div class="content">

                <h4><?php echo the_title(); ?></h4>

              </div>

            </a>

          </div>
          <?php
            endwhile;
            endif;
            wp_reset_postdata();
          ?>
          <!-- <div class="single-events">

              <a href="#">

                <div class="title">

                  <span>News & Events</span>

                </div>

                <div class="content">

                  <h4>Our UAE branch reaches new heights.</h4>

                </div>

              </a>

          </div>

          <div class="single-events">

            <a href="#">

              <div class="title">

                <span>News & Events</span>

              </div>

              <div class="content">

                <h4>Our UAE branch reaches new heights.</h4>

              </div>

            </a>

          </div>

          <div class="single-events">

            <a href="#">

              <div class="title">

                <span>News & Events</span>

              </div>

              <div class="content">

                <h4>Our UAE branch reaches new heights.</h4>

              </div>

            </a>

          </div> -->

        </div>

      </div>

    </div>

    <div class="link-part">

      <a href="<?php echo $home_all_news_and_events_link; ?>" class="learn-more"><?php echo $home_see_all_news_and_events_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i></a>

    </div>

  </div>

</section>
<?php
  $home_our_facilities_left_image_part = get_field('home_our_facilities_left_image_part');
  $home_our_facilities_right_image_part = get_field('home_our_facilities_right_image_part');
  $home_our_facilities_first_title = get_field('home_our_facilities_first_title');
  $home_our_facilities_second_title = get_field('home_our_facilities_second_title');
  $home_our_facilities_content_area = get_field('home_our_facilities_content_area');
  $home_our_facilities_cta_text = get_field('home_our_facilities_cta_text');
  $home_our_facilities_cta_link = get_field('home_our_facilities_cta_link');
?>
<section class="falities-part">

  <div class="faci-left" data-aos="fade-up" data-aos-duration="1500">

    <img src="<?php echo $home_our_facilities_left_image_part['sizes']['home_our_facilities_right_image']?>" alt="">

  </div>

  <div class="faci-middle" data-aos="fade-up" data-aos-duration="1500">

    <div class="title">

      <h5><?php echo $home_our_facilities_first_title; ?></h5>

      <h3><?php echo $home_our_facilities_second_title; ?></h3>

    </div>

    <div class="content">

      <p><?php echo $home_our_facilities_content_area; ?></p>

    </div>

    <a href="<?php echo $home_our_facilities_cta_link; ?>" class="learn-more"><?php echo $home_our_facilities_cta_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i></a>

  </div>

  <div class="faci-right" data-aos="fade-up" data-aos-duration="1500">

    <img src="<?php echo $home_our_facilities_right_image_part['sizes']['home_our_facilities_right_image']?>" alt="">

  </div>

</section>
<?php
  $home_investor_relations_first_title = get_field('home_investor_relations_first_title');
  $home_investor_relations_second_title = get_field('home_investor_relations_second_title');
?>
<section class="investors">

  <div class="container">

    <div class="title">

      <h5 data-aos="fade-up" data-aos-duration="2000"><?php echo $home_investor_relations_first_title; ?></h5>

      <h2 data-aos="fade-up" data-aos-duration="3000"><?php echo $home_investor_relations_second_title; ?></h2>

    </div>

    <div class="relations-full">

      <div class="each-relations">
        <?php if( have_rows('home_each_investor_blocks') ): ?>
        <?php while( have_rows('home_each_investor_blocks') ): the_row(); 
          $count = get_sub_field('count');
          $title = get_sub_field('title');
          $content = get_sub_field('content');
        ?>
        <div class="single-telation" data-aos="fade-up" data-aos-duration="2500">

          <div class="content-full">

            <div class="title">

              <h5><?php echo $count; ?></h5>

              <h3><?php echo $title; ?></h3>

            </div>

            <div class="content">

              <p><?php echo $content; ?></p>

            </div>

          </div>

        </div>
        <?php endwhile; ?>
        <?php endif; ?>
        <?php
          $home_investor_relations_contact_text = get_field('home_investor_relations_contact_text');
          $home_investor_relations_contact_link = get_field('home_investor_relations_contact_link')
        ?>
        <div class="single-telation contact-block" data-aos="fade-up" data-aos-duration="2500">

          <a href="<?php echo $home_investor_relations_contact_link; ?>">

            <div class="content-full center-part">

              <div class="title">

                <h3><?php echo $home_investor_relations_contact_text; ?></h3>

              </div>

            </div>

          </a>

        </div>

      </div>
      <?php
        $home_investor_relations_cta_text = get_field('home_investor_relations_cta_text');
        $home_investor_relations_cta_link = get_field('home_investor_relations_cta_link')
      ?>
      <div class="learn-more-main">

        <a href="<?php echo $home_investor_relations_cta_link; ?>" class="learn-more"><?php echo $home_investor_relations_cta_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i></a>

      </div>

    </div>

  </div>

</section>

