<?php
/*

Template Name: Events Template

*/
?>
<?php
	$events_banner_first_title = get_field('events_banner_first_title');
	$events_banner_second_title = get_field('events_banner_second_title');
  $events_banner_image = get_field('events_banner_image');
?>
<section class="inner-banner" style="background-image: url(<?php echo $events_banner_image['url']; ?>);">
  <div class="banner-layout">
    <div class="title container" data-aos="fade-up" data-aos-duration="1500">
        <h5><?php echo $events_banner_first_title; ?></h5>
        <h2><?php echo $events_banner_second_title; ?></h2>
    </div>
  </div>
</section>
<?php
	$events_news_first_title = get_field('events_news_first_title');
	$events_news_second_title = get_field('events_news_second_title');
	$events_news_see_all_news_text = get_field('events_news_see_all_news_text');
	$events_news_see_all_news_link = get_field('events_news_see_all_news_link');
?>
<section class="news-and-events events-news-part">
  <div class="container">
    <div class="title-part" data-aos="fade-up" data-aos-duration="2000">
			<h5><?php echo $events_news_first_title; ?></h5>
			<h2><?php echo $events_news_second_title; ?></h2>
    </div>
    <div class="full-branch-part">
    	<?php
    	$events_news_first_block_title = get_field('events_news_first_block_title');
    	$events_news_first_block_date = get_field('events_news_first_block_date');
    	$events_news_first_block_cta_text = get_field('events_news_first_block_cta_text');
    	$events_news_first_block_cta_link = get_field('events_news_first_block_cta_link');
    	$events_news_first_block_image = get_field('events_news_first_block_image');
    	?>
      <div class="first-branch each-part" data-aos="fade-up" data-aos-duration="2000">
        <div class="content-part">
            <h3><?php echo $events_news_first_block_title; ?></h3>
            <div class="date-part">
              <span><?php echo $events_news_first_block_date; ?></span>
            </div>
            <div class="link-part">
              <a href="<?php echo $events_news_first_block_cta_link; ?>" class="learn-more"><?php echo $events_news_first_block_cta_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i></a>
            </div>
        </div>
        <div class="img-part">
          <img src="<?php echo $events_news_first_block_image['url']; ?>" alt="">
        </div>
      </div>
      <?php
      $events_news_second_block_title = get_field('events_news_second_block_title');
      $events_news_second_block_date = get_field('events_news_second_block_date');
      $events_news_second_block_cta_text = get_field('events_news_second_block_cta_text');
      $events_news_second_block_cta_link = get_field('events_news_second_block_cta_link');
      $events_news_second_block_image = get_field('events_news_second_block_image');
      ?>
      <div class="second-branch each-part" data-aos="fade-up" data-aos-duration="2000">
          <div class="content-part">
            <h3><?php echo $events_news_second_block_title; ?></h3>
            <div class="date-part">
              <span><?php echo $events_news_second_block_date; ?></span>
            </div>
            <div class="link-part">
              <a href="<?php echo $events_news_second_block_cta_link; ?>" class="learn-more"><?php echo $events_news_second_block_cta_text; ?><i class="fa fa-angle-right" aria-hidden="true"></i></a>
            </div>
          </div>
          <div class="img-part">
            <img src="<?php echo $events_news_second_block_image['url']; ?>" alt="">
          </div>
      </div>
      <div class="third-branch each-part" data-aos="fade-up" data-aos-duration="2000">
        <div class="each-events">
        	<?php  
            $number = 1;
            $news_args = array(

              'post_type' => 'news',

              'post_status' => 'publish',

              'posts_per_page' => 4

            );
            $news_query = new WP_Query( $news_args );
            if ( $news_query->have_posts() ):
            while ( $news_query->have_posts() ) : $news_query->the_post();
          ?>
          <?php
          $common_news_and_events = get_field('common_news_and_events','option');
          ?>
          <div class="single-events">
            <a href="<?php the_permalink(); ?>">
              <div class="title">
                <span><?php echo $common_news_and_events; ?></span>
              </div>
              <div class="content">
                <h4><?php echo the_title(); ?></h4>
              </div>
            </a>
          </div>
          <?php
            endwhile;
            endif;
            wp_reset_postdata();
          ?>
          <!-- <div class="single-events">
              <a href="#">
                <div class="title">
                  <span>News & Events</span>
                </div>
                <div class="content">
                  <h4>Our UAE branch reaches new heights.</h4>
                </div>
              </a>
          </div>
          <div class="single-events">
            <a href="#">
              <div class="title">
                <span>News & Events</span>
              </div>
              <div class="content">
                <h4>Our UAE branch reaches new heights.</h4>
              </div>
            </a>
          </div>
          <div class="single-events">
            <a href="#">
              <div class="title">
                <span>News & Events</span>
              </div>
              <div class="content">
                <h4>Our UAE branch reaches new heights.</h4>
              </div>
            </a>
          </div> -->
        </div>
      </div>
		</div>
		<div class="news-block-part">
			<?php  
      $number = 1;
      $news_args = array(

        'post_type' => 'news',

        'post_status' => 'publish',

        'posts_per_page' => 6

      );
      $news_query = new WP_Query( $news_args );
      if ( $news_query->have_posts() ):
      while ( $news_query->have_posts() ) : $news_query->the_post();
      ?>
      <?php
      $read_more_translation = get_field('read_more_translation','option');
      ?>
			<div class="single">
				<?php echo the_post_thumbnail(url); ?>
				<h4><?php echo the_title(); ?></h4>
				<div class="link-part">
					<a href="<?php the_permalink(); ?>" class="learn-more"><?php echo $read_more_translation; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
				</div>
			</div>
			<?php 
			endwhile; 
			endif; 
			wp_reset_postdata();
			?>
		</div>
		<div class="link-part all-news-link">
			<a href="<?php echo $events_news_see_all_news_link; ?>" class="learn-more"><?php echo $events_news_see_all_news_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
		</div>
  </div>
</section>
<?php
	$events_press_release_first_title = get_field('events_press_release_first_title');
	$events_press_release_second_title = get_field('events_press_release_second_title');
?>
<section class="press-release-sec">
	<div class="container">
		<div class="title">
				<h5><?php echo $events_press_release_first_title; ?></h5>
				<h2><?php echo $events_press_release_second_title; ?></h2>
		</div>
		<div class="main-press-rel-part">
			<?php if( have_rows('events_press_release_main_press_release') ): ?>
			<?php while( have_rows('events_press_release_main_press_release') ): the_row(); 
			$title = get_sub_field('title');
			$content = get_sub_field('content');
			$cta_text = get_sub_field('cta_text');
			$cta_link = get_sub_field('cta_link');
			?>

			<div class="single-press-rel">
				<div class="single">
					<h3><?php echo $title; ?></h3>
					<p><?php echo $content; ?></p>
					<div class="link-part">
						<a href="<?php echo $cta_link; ?>" class="learn-more"><?php echo $cta_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
					</div>
				</div>
			</div>
			<?php endwhile; ?>
			<?php endif; ?>
		</div>
		<div class="second-press-rel-part">
			<?php  
	      $number = 1;
	      $news_args = array(

	        'post_type' => 'press-release',

	        'post_status' => 'publish',

	        'posts_per_page' => 4

	      );
	      $news_query = new WP_Query( $news_args );
	      if ( $news_query->have_posts() ):
	      while ( $news_query->have_posts() ) : $news_query->the_post();
	    ?>
	    <?php 
	    	$front_display_content = get_field('front_display_content');
	    	$news_inner_date = get_field('news_inner_date');
	    ?>
	    <?php
	    $read_more_translation = get_field('read_more_translation','option');
	    ?>
			<div class="single">
				<h3><?php echo the_title(); ?></h3>
				<p><?php echo $front_display_content; ?></p>
				<div class="link-part">
					<a href="<?php the_permalink(); ?>" class="learn-more"><?php echo $read_more_translation; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
				</div>
			</div>
			<?php
        endwhile;
        endif;
        wp_reset_postdata();
      ?>
		</div>
		<?php
		$events_press_release_see_all_press_release_text = get_field('events_press_release_see_all_press_release_text');
		$events_press_release_see_all_press_release_link = get_field('events_press_release_see_all_press_release_link');
		?>
		<div class="link-part all-press-rel-link">
			<a href="<?php echo $events_press_release_see_all_press_release_link; ?>" class="learn-more"><?php echo $events_press_release_see_all_press_release_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
		</div>
	</div>
</section>
<?php
	$events_contact_media_first_title = get_field('events_contact_media_first_title');
	$events_contact_media_second_title = get_field('events_contact_media_second_title');
?>
<section class="contact-media-rel">
	<div class="container">
		<div class="title">
			<h5><?php echo $events_contact_media_first_title; ?></h5>
			<h2><?php echo $events_contact_media_second_title; ?></h2>
		</div>
		<div class="address-block">
			<?php if( have_rows('events_contact_media_contact_blocks') ): ?>
			<?php while( have_rows('events_contact_media_contact_blocks') ): the_row(); 
			$title = get_sub_field('title');
			$content = get_sub_field('content');
			$email = get_sub_field('email');
			?>
			<div class="single">
				<h3><?php echo $title; ?></h3>
				<p><?php echo $content; ?> </p>
				<a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a>
			</div>
			<?php endwhile; ?>
			<?php endif; ?>
		</div>
	</div>
</section>