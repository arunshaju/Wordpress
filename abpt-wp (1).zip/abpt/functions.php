<?php

/**

 * Roots includes

 */

require_once locate_template('/lib/utils.php');           // Utility functions

require_once locate_template('/lib/init.php');            // Initial theme setup and constants

require_once locate_template('/lib/wrapper.php');         // Theme wrapper class

require_once locate_template('/lib/sidebar.php');         // Sidebar class

require_once locate_template('/lib/config.php');          // Configuration

require_once locate_template('/lib/activation.php');      // Theme activation

require_once locate_template('/lib/titles.php');          // Page titles

require_once locate_template('/lib/cleanup.php');         // Cleanup

require_once locate_template('/lib/nav.php');             // Custom nav modifications

require_once locate_template('/lib/gallery.php');         // Custom [gallery] modifications

require_once locate_template('/lib/comments.php');        // Custom comments modifications

require_once locate_template('/lib/relative-urls.php');   // Root relative URLs

require_once locate_template('/lib/widgets.php');         // Sidebars and widgets

require_once locate_template('/lib/scripts.php');         // Scripts and stylesheets

// require_once locate_template('/lib/cpt.php');         	  // Custom Posttype functions

require_once locate_template('/lib/cpt-news.php');         	  // Custom Posttype functions

require_once locate_template('/lib/cpt-solutions.php');         	  // Custom Posttype functions

require_once locate_template('/lib/cpt-products.php');         	  // Custom Posttype functions

require_once locate_template('/lib/cpt-press-release.php');         	  // Custom Posttype functions

require_once locate_template('/lib/cpt-exchange-announcement.php');         	  // Custom Posttype functions

require_once locate_template('/lib/rename-posts.php');    // Rename Posts functions

require_once locate_template('/lib/breadcrumb.php');      // BreadCrumb functions

require_once locate_template('/lib/ajax.php');        	  // Ajax functions

require_once locate_template('/lib/insertcpt.php');        	  // Ajax functions

require_once locate_template('/lib/custom.php');          // Custom functions

if( function_exists('acf_add_options_page') ) {

	acf_add_options_page();

}

// For IE

function add_jquery_ui() {
    wp_enqueue_script( 'jquery-ui-core' );
    wp_enqueue_script( 'jquery-ui-widget' );
    wp_enqueue_script( 'jquery-ui-mouse' );
    wp_enqueue_script( 'jquery-ui-accordion' );
    wp_enqueue_script( 'jquery-ui-autocomplete' );
    wp_enqueue_script( 'jquery-ui-slider' );
    wp_enqueue_script( 'jquery-ui-tabs' );
    wp_enqueue_script( 'jquery-ui-sortable' );
    wp_enqueue_script( 'jquery-ui-draggable' );
    wp_enqueue_script( 'jquery-ui-droppable' );
    wp_enqueue_script( 'jquery-ui-datepicker' );
    wp_enqueue_script( 'jquery-ui-resize' );
    wp_enqueue_script( 'jquery-ui-dialog' );
    wp_enqueue_script( 'jquery-ui-button' );
}
add_action( 'wp_enqueue_scripts', 'add_jquery_ui' );

add_filter( 'wpcf7_load_js', '__return_false' );
add_filter( 'wpcf7_load_css', '__return_false' );


