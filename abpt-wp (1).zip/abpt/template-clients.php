<?php
/*

Template Name: Clients Page Template

*/
?>
<?php
$clients_page_banner_image = get_field('clients_page_banner_image');
$clients_page_banner_first_title = get_field('clients_page_banner_first_title');
$clients_page_banner_second_title = get_field('clients_page_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $clients_page_banner_image['url']; ?>);">
  <div class="banner-layout">
    <div class="title container" data-aos="fade-up" data-aos-duration="1500">
        <h5><?php echo $clients_page_banner_first_title; ?></h5>
        <h2><?php echo $clients_page_banner_second_title; ?></h2>
    </div>
  </div>
</section>
<section class="about-our-clients client-logo-sec">
	<div class="container">
		<div class="full-logo-part">
			<?php if( have_rows('clients_page_each_logos') ): ?>
			<?php while( have_rows('clients_page_each_logos') ): the_row(); 
			$logo = get_sub_field('logo');
			?>
			<div class="logo">
				<img src="<?php echo $logo['url']; ?>" alt="">
			</div>
			<?php endwhile; ?>
			<?php endif; ?>
		</div>
	</div>
</section>
<?php
$clients_page_testimonials_first_title = get_field('clients_page_testimonials_first_title');
$clients_page_testimonials_second_title = get_field('clients_page_testimonials_second_title');
?>
<section class="clients-testimonials">
	<div class="container">
		<h5><?php echo $clients_page_testimonials_first_title; ?></h5>  
		<h2><?php echo $clients_page_testimonials_second_title; ?></h2>
		<div class="testimonial-block">
			<div class="testimonials">
				<?php if( have_rows('clients_page_each_testimonials') ): ?>
				<?php while( have_rows('clients_page_each_testimonials') ): the_row(); 
				$image = get_sub_field('image');
				$content = get_sub_field('content');
				$client = get_sub_field('client');
				?>
				<div class="single">
					<div class="logo-part">
						<img src="<?php echo $image['url']; ?>" alt="">
					</div>
					<div class="content-part">
						<p>"<?php echo $content; ?>"</p>
					</div>
					<div class="name-part">
						<span><?php echo $client; ?></span>
					</div>
				</div>
				<?php endwhile; ?>
				<?php endif; ?>
			</div>
			<ul>
				<li class="prev-test"><a href="JavaScript:Void(0);"><i class="fa fa-angle-left" aria-hidden="true"></i></a></i></li>
				<li class="next-test"><a href="JavaScript:Void(0);"><i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
			</ul>
		</div>
	</div>
</section>