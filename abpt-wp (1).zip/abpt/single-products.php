<?php
	$solution_inner_banner_image = get_field('solution_inner_banner_image');
	$solution_inner_banner_first_title = get_field('solution_inner_banner_first_title');
	$solution_inner_banner_second_title = get_field('solution_inner_banner_second_title');
?>
<section class="inner-banner" style="background: url(<?php echo $solution_inner_banner_image['url']; ?>);">
  <div class="banner-layout">
    <div class="title container" data-aos="fade-up" data-aos-duration="1500">
        <h5><?php echo $solution_inner_banner_first_title; ?></h5>
        <h2><?php echo $solution_inner_banner_second_title; ?></h2>
    </div>
  </div>
</section>
<?php
	$solution_inner_empowering_first_title = get_field('solution_inner_empowering_first_title');
	$solution_inner_empowering_second_title = get_field('solution_inner_empowering_second_title');
	$solution_inner_empowering_content = get_field('solution_inner_empowering_content');
?>
<section class="empowering-part" data-aos="fade-up" data-aos-duration="1500">
  <div class="container">
    <div class="content-part">
      <div class="title">
        <h5><?php echo $solution_inner_empowering_first_title; ?></h5>
        <h2><?php echo $solution_inner_empowering_second_title; ?></h2>
      </div>
      <div class="para-content">
        <p><?php echo $solution_inner_empowering_content; ?></p>
      </div>
		</div>
		<div class="logo-card-part">
			<?php if( have_rows('solution_inner_empowering_logo_part') ): ?>
			<?php while( have_rows('solution_inner_empowering_logo_part') ): the_row(); 
				$image = get_sub_field('image');
				$title = get_sub_field('title');
				$cta_text = get_sub_field('cta_text');
				$cta_url = get_sub_field('cta_url');
			?>
			<div class="single-logo" data-aos="fade-up" data-aos-duration="1500">
				<img src="<?php echo $image['url'] ?>" alt="">
				<h3><?php echo $title; ?></h3>
				<a href="<?php echo $cta_url; ?>" class="learn-more"><?php echo $cta_text; ?><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
			</div>
			<?php endwhile; ?>
			<?php endif; ?>
		</div>
  </div>
</section>
<section class="inner-products-desc">
	<div class="container">
	  <div class="full-products-part">
	  	<?php if( have_rows('solution_inner_page_block_part') ): ?>
  		<?php while( have_rows('solution_inner_page_block_part') ): the_row(); 
			$image = get_sub_field('image');
			$title = get_sub_field('title');
			$content = get_sub_field('content');
			$download_text = get_sub_field('download_text');
			$pdf_url = get_sub_field('pdf_url');
			?>
	    <div class="block-part">
	      <div class="img-part">
	        <img src="<?php echo $image['url']; ?>" alt="">
	      </div>
	      <div class="content-part">
	        <h2><?php echo $title; ?></h2>
	        <p><?php echo $content; ?></p>
	        <div class="link-part">
	          <a href="<?php echo $pdf_url; ?>"><i class="fa fa-download" aria-hidden="true"></i><span><?php echo $download_text; ?></span></a>
	        </div>
	      </div>
	    </div>
	    <?php endwhile; ?>
	  	<?php endif; ?>
	  </div>
	</div>
</section>