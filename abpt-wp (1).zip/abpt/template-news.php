<?php
/*

Template Name: News Page Template

*/
?>
<?php
$news_banner_image = get_field('news_banner_image');
$news_banner_first_title = get_field('news_banner_first_title');
$news_banner_second_title = get_field('news_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $news_banner_image['url']; ?>);">
  <div class="banner-layout">
    <div class="title container" data-aos="fade-up" data-aos-duration="1500">
        <h5><?php echo $news_banner_first_title; ?></h5>
        <h2><?php echo $news_banner_second_title; ?></h2>
    </div>
  </div>
</section>
<section class="list-all-news-sec">
	<div class="container">
		<select class="event-type-select">
			<?php
			$select_year_translation = get_field('select_year_translation','option')
			?>
	        <option value="all"><?php echo $select_year_translation; ?></option>
	        <?php if( have_rows('news_year_wise_filters', 'option') ): ?>
        	<?php while( have_rows('news_year_wise_filters', 'option') ): the_row(); 
        		$year = get_sub_field('year');
        		$slug = get_sub_field('slug');
        	?>
	        <option value="<?php echo $slug; ?>"><?php echo $year; ?></option>
	    	<?php endwhile; ?>
	    	<?php endif; ?>
      	</select>
		<div class="each-news-part">
			<?php  
      $number = 1;
      $news_args = array(

        'post_type' => 'news',

        'post_status' => 'publish',

        'posts_per_page' => -1

      );
      $news_query = new WP_Query( $news_args );
      if ( $news_query->have_posts() ):
      while ( $news_query->have_posts() ) : $news_query->the_post();
      	$news_select_category = get_the_terms( $post->ID, 'newstax' );
							
        $designation = get_the_terms( $post->ID, 'newstax' );
		foreach($news_select_category as $news_select_category) {
			$cat_type = $news_select_category->slug;
		}
      ?>
      <?php
      $news_inner_date = get_field('news_inner_date');
      ?>
			<div class="single  news-cat"   data-eventtype="<?php echo $cat_type; ?>">
				<div class="img-part">
					<!-- <img src="assets/images/middle-east-solar.png" alt=""> -->
					<?php echo the_post_thumbnail(url); ?>
				</div>
				<div class="title">
					<span><?php echo $news_inner_date; ?></span>
					<h3><?php echo the_title(); ?></h3>
				</div>
				<?php
			    $read_more_translation = get_field('read_more_translation','option');
			    ?>
				<div class="link-part">
					<a href="<?php the_permalink(); ?>" class="learn-more"><?php echo $read_more_translation; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
				</div>
			</div>
			<?php 
			endwhile; 
			endif; 
			wp_reset_postdata();
			?>
		</div>
	</div>
</section>