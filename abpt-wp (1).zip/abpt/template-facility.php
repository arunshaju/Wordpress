
<?php
/*

Template Name: Facility Page Template

*/
?>

<?php
	$products_inner_banner_image = get_field('products_inner_banner_image');
	$products_inner_banner_first_title = get_field('products_inner_banner_first_title');
	$products_inner_banner_second_title = get_field('products_inner_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $products_inner_banner_image['url']; ?>);">
	<div class="banner-layout">
		<div class="title container" data-aos="fade-up" data-aos-duration="1500">
				<h5><?php echo $products_inner_banner_first_title; ?></h5>
				<h2><?php echo $products_inner_banner_second_title; ?></h2>
		</div>
	</div>
</section>
<section class="full-energy-sec">
	<div class="container">
		<?php if( have_rows('products_inner_each_block_part') ): ?>
		<?php while( have_rows('products_inner_each_block_part') ): the_row(); 
		$title = get_sub_field('title');
		?>
		<div class="full-energy-cont">
			<div class="title">
				<h2><?php echo $title; ?></h2>
			</div>
			<div class="energy-full">
				<?php if( have_rows('inner_block_part') ): ?>
				<?php while( have_rows('inner_block_part') ): the_row(); 
				$image = get_sub_field('image');
				$title = get_sub_field('title');
				?>
				<div class="single">
					<img src="<?php echo $image['url']; ?>" alt="">
					<h3><?php echo $title; ?></h3>
				</div>
				<?php endwhile; ?>
				<?php endif; ?>
				<!-- <div class="single">
					<img src="assets/images/solar-trackers.png" alt="">
					<h3>Components for Solar Trackers</h3>
				</div>
				<div class="single">
					<img src="assets/images/solar-trackers.png" alt="">
					<h3>Components for Solar Trackers</h3>
				</div>
				<div class="single">
					<img src="assets/images/solar-trackers.png" alt="">
					<h3>Components for Solar Trackers</h3>
				</div>
				<div class="single">
					<img src="assets/images/solar-trackers.png" alt="">
					<h3>Components for Solar Trackers</h3>
				</div> -->
			</div>
		</div>
		<?php endwhile; ?>
		<?php endif; ?>
		<!-- <div class="full-energy-cont">
			<div class="title">
				<h2>PV SOLAR</h2>
			</div>
			<div class="energy-full">
				<div class="single">
					<img src="assets/images/solar-trackers.png" alt="">
					<h3>Components for Solar Trackers</h3>
				</div>
				<div class="single">
					<img src="assets/images/solar-trackers.png" alt="">
					<h3>Components for Solar Trackers</h3>
				</div>
				<div class="single">
					<img src="assets/images/solar-trackers.png" alt="">
					<h3>Components for Solar Trackers</h3>
				</div>
				<div class="single">
					<img src="assets/images/solar-trackers.png" alt="">
					<h3>Components for Solar Trackers</h3>
				</div>
			</div>
		</div> -->
	</div>
</section>