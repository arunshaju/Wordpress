<div id="preloader">

  <div id="status">&nbsp;</div>

</div>

<header>

  <div class="container">

    <nav>

      <div class="nav-bars">

          <a href="JavaScript:void(0);" class="js-menu-open menu-open">

            <i class="fa fa-bars" aria-hidden="true"></i>

          </a>

      </div>

      <div class="logo-top">
        <a href="<?php echo get_home_url(); ?>">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/ABPT.svg" alt="">
        </a>

      </div>

      <div class="lang-switcher">

        <!-- <?php

        //if (has_nav_menu('primary_navigation')) :

        //wp_nav_menu(array('theme_location' => 'primary_navigation', 'menu_class' => 'navbar-nav ml-auto'));

        //endif;

        ?> -->

        <!-- <select data-placeholder="Lang" class="chosen-select" id="lang-switch">

          <option selected="selected">EN</option>

          <option>AR</option>

        </select> -->

        <!-- <ul>
			   <?php //pll_the_languages( array( 'show_flags' => 1,'show_names' => 1,'dropdown' => 1 ) ); ?>
		    </ul> -->

        <ul><?php pll_the_languages();?></ul>

      </div>

    </nav>

    <div class="js-side-nav-container side-nav-container">

      <div class="js-side-nav side-nav">

        <div class="left-part">
          <a href="<?php echo get_home_url(); ?>">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/ABPT.svg" alt="">
          </a>
          <a href="JavaScript:void(0);" class="js-menu-close menu-close">

              <!-- <i class="fa fa-times"></i> -->

              <img src="<?php echo get_template_directory_uri(); ?>/assets/images/close-icon.svg" alt="">

            </a>

            <a href="#" class="back-btn" id="back-btn-anim"><i class="fa fa-angle-double-left" aria-hidden="true"></i></a>

            <div class="main-menu-left">
              <?php if( have_rows('first_menu_each_menu_item','option') ): ?>
              <ul>
                <?php while( have_rows('first_menu_each_menu_item','option') ): the_row(); 
                $first_menu_menu_name = get_sub_field('first_menu_menu_name');
                $first_menu_menu_url = get_sub_field('first_menu_menu_url');
                $menu_id = get_sub_field('menu_id');
                ?>
                  <li><a href="<?php echo $first_menu_menu_url; ?>" class="btn1" id="<?php echo $menu_id; ?>"><ul><li><?php echo $first_menu_menu_name; ?></li><li><i class="fa fa-angle-right" aria-hidden="true"></i></li></ul></a></li>
                <?php endwhile; ?>
              </ul>
              <?php endif; ?>

            </div>

        </div>

        <div class="right-part">

          <div class="each-right-component">

            <div class="right-nav-menu" id="parent">
              <?php if( have_rows('second_menu_each_menu_item','option') ): ?>
              <?php while( have_rows('second_menu_each_menu_item','option') ): the_row(); 
              $second_menu_menu_id = get_sub_field('second_menu_menu_id');
              $second_inner_parent_cta_text = get_sub_field('second_inner_parent_cta_text');
              $parent_cta_link = get_sub_field('parent_cta_link');
              ?>
              <ul class="<?php echo $second_menu_menu_id; ?>">
                <?php while( have_rows('second_inner_menu_item','option') ): the_row(); 
                $second_inner_content = get_sub_field('second_inner_content');
                $second_inner_menu_id = get_sub_field('second_inner_menu_id');
                $second_inner_menu_url = get_sub_field('second_inner_menu_url');
                $check_open_in_new_tab = get_sub_field('check_open_in_new_tab');
                ?>
                <?php
                $go_to_text_translation = get_field('go_to_text_translation' , 'option');
                ?>
                <li><a href="<?php echo $second_inner_menu_url; ?>" id="<?php echo $second_inner_menu_id; ?>" class="btn2"
                <?php if($check_open_in_new_tab == "enable-new-tab"){ ?> target="blank" <?php } ?>><ul><li><?php echo $second_inner_content; ?>
                </li><li><i class="fa fa-angle-right" aria-hidden="true"></i></li></ul></a></li>
                <?php endwhile;?>
                <li class="menu-parent-cta"><a href="<?php echo $parent_cta_link; ?>" class="menu-part-tag"><?php echo $go_to_text_translation; ?> <!-- <?php //echo $second_inner_parent_cta_text; ?> --><i class="fa fa-angle-right menu-parent-icon" aria-hidden="true"></i></a></li>
              </ul>
              <?php endwhile; ?>
              <?php endif; ?>
            </div>
            <?php if( have_rows('second_menu_each_menu_item','option') ): ?>
            <?php while( have_rows('second_menu_each_menu_item','option') ): the_row();?>
            <?php while( have_rows('second_inner_menu_item','option') ): the_row();
              $second_inner_menu_id = get_sub_field('second_inner_menu_id');
              $second_inner_menu_content_part = get_sub_field('second_inner_menu_content_part');
            ?> 
            <div class="right-nav-content <?php echo $second_inner_menu_id; ?>">

              <div class="content-part">
                <?php echo $second_inner_menu_content_part; ?>
              </div>

            </div>
            <?php endwhile; ?>
            <?php endwhile; ?>
            <?php endif; ?>

          </div>

          <div class="right-open-part">

            <div class="each-article">

              <?php if( have_rows('header_default_part_image_and_content', 'option') ): ?>
              <?php while( have_rows('header_default_part_image_and_content', 'option') ): the_row(); 
                $header_default_part_main_url = get_sub_field('header_default_part_main_url');
                $header_default_part_image = get_sub_field('header_default_part_image');
                $header_default_part_sub_title = get_sub_field('header_default_part_sub_title');
                $header_default_part_read_more = get_sub_field('header_default_part_read_more');
                $header_default_part_read_more_cta = get_sub_field('header_default_part_read_more_cta');
              ?>

              <div class="first-article">

                <a target="blank" href="<?php echo $header_default_part_main_url; ?>">

                  <div class="img-part">

                    <img src="<?php echo $header_default_part_image['url'];?>" alt="">

                  </div>

                  <div class="content-part">

                    <span><?php echo $header_default_part_sub_title; ?></span>

                    <h5>Capital with Purpose</h5>

                    <a target="blank" href="<?php echo $header_default_part_read_more_cta; ?>" class="read-report"><?php echo $header_default_part_read_more; ?></a>

                  </div>

                </a>

              </div>

              <?php endwhile; ?>
              <?php endif; ?>


            </div>

          </div>

        </div>

      </div>

    </div>

  </div>

</header>