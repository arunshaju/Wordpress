<footer>
  <?php wp_footer(); ?>
  <div class="footer-full-width">

    <div class="container">

      <div class="footer-part">
        <?php if( have_rows('each_footer', 'option') ): ?>
        <?php while( have_rows('each_footer', 'option') ): the_row(); ?>
        <div class="footer1">

          <ul>
            <?php if( have_rows('footer', 'option') ): ?>
            <?php while( have_rows('footer', 'option') ): the_row(); 
              $text_part = get_sub_field('text_part');
              $link_part = get_sub_field('link_part');
            ?>
            <li><a href="<?php echo $link_part; ?>"><?php echo $text_part; ?></a></li>
            <?php endwhile; ?>
            <?php endif; ?>
          </ul>
        </div>
        <?php endwhile; ?>
        <?php endif; ?>

        <div class="footer5">

          <ul>
            <?php if( have_rows('footer_social_media', 'option') ): ?>
            <?php while( have_rows('footer_social_media', 'option') ): the_row(); 
              $type = get_sub_field('type');
              $link = get_sub_field('link');
            ?>
            <li><a href="<?php echo $link; ?>" target="blank"><i class="fa <?php echo $type; ?>" aria-hidden="true"></i></a></li>
            <?php endwhile; ?>
            <?php endif; ?>

            <!-- <li><a href="#" target="blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>

            <li><a href="#" target="blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li> -->

          </ul>

        </div>

      </div>

    </div>

  </div>

  <div class="footer-bottom">

    <div class="container">

      <div class="left-part">

        <ul>
          <?php if(have_rows('footer_bottom_left_cta', 'option') ): ?>
          <?php while(have_rows('footer_bottom_left_cta' ,'option') ): the_row();
            $cta_text = get_sub_field('cta_text');
            $cta_link = get_sub_field('cta_link');
          ?>
          <li><a href="<?php echo $cta_link; ?>"><?php echo $cta_text; ?></i></a></li>
          <?php endwhile; ?>
          <?php endif; ?>
          <!-- <li><a href="#">Privacy Policy</a></li>

          <li><a href="#">Cookie Policy</a></li>

          <li><a href="#">Terms of Use</a></li> -->

        </ul>

      </div>

      <div class="middle-part">

      </div>
      <?php
      $footer_bottom_copy_right_text = get_field('footer_bottom_copy_right_text', 'option');
      ?>
      <div class="right-part">

        <span><?php echo $footer_bottom_copy_right_text; ?></span>

      </div>

    </div>

  </div>

</footer>
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery.min.js"></script>

  <script>window.jQuery || document.write('<script src="assets/scripts/jquery.min.js"><\/script>')</script>

  <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/scripts/plugins.min.js"></script>
  <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/scripts/modernizr.min.js"></script>

  <!-- <script type="text/javascript" src="<?php //echo get_template_directory_uri(); ?>/assets/scripts/app.min.js"></script> -->

  <!-- <script type="text/javascript" src="<?php //echo get_template_directory_uri(); ?>/assets/scripts/aos.js"></script> -->

  <script src="https://apis.google.com/js/platform.js" async defer></script>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>

  <script>

    AOS.init();

  </script>
  <script>
    $(document).ready(function(){
      $(".right-nav-content").css({"display":"none"});
    });
  </script>


<?php wp_footer(); ?>



<!-- Google Analytics -->

<script>

(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){

(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),

m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)

})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');



ga('create', 'UA-XXXXX-Y', 'auto');

ga('send', 'pageview');

</script>

<!-- End Google Analytics -->

