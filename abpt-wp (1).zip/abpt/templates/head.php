<!DOCTYPE html>

<html class="no-js" <?php language_attributes(); ?>>

    <head>

      <meta name="google-site-verification" content="WacrP3KCmlmMurzWZzHNCRjQ1bO1yHzjFMtRAlDKjU8" />

      <meta charset="utf-8">

      <meta http-equiv="x-ua-compatible" content="ie=edge">

      <title><?php wp_title(''); ?></title>

      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" />

      <link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon.ico" type="image/x-icon">

      <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon/favicon.ico" type="image/x-icon">

      <!-- <link rel="stylesheet" type="text/css" href="<?php //echo get_template_directory_uri(); ?>/assets/styles/styles.min.css"> -->

      <!-- <link rel="stylesheet" type="text/css" href="<?php //echo get_template_directory_uri(); ?>/assets/styles/custom.css"> -->

      <!-- <link rel="stylesheet" type="text/css" href="assets/styles/aos.css"> -->

      <!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"> -->

      <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

      <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/scripts/modernizr.min.js"></script>

      <link href="https://fonts.googleapis.com/css?family=Hind&display=swap" rel="stylesheet">

  <!--[if lt IE 9]>

    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>

    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

  <![endif]-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="msvalidate.01" content="2B619DA791089DC5C0542E8D3752FD74" />
    <?php wp_head(); ?>
    </head>