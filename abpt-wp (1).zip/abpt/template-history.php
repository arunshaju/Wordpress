<?php
/*

Template Name: History Template

*/
?>
	<?php
	$history_banner_first_title = get_field('history_banner_first_title');
	$history_banner_second_title = get_field('history_banner_second_title');
	$history_banner_image = get_field('history_banner_image');
	?>
	<section class="inner-banner" style="background-image: url(<?php echo $history_banner_image['url']; ?>);">
    <div class="banner-layout">
      <div class="title container" data-aos="fade-up" data-aos-duration="1500">
          <h5><?php echo $history_banner_first_title; ?></h5>
          <h2><?php echo $history_banner_second_title; ?></h2>
      </div>
    </div>
	</section>
	<?php
	$history_empowering_first_title = get_field('history_empowering_first_title');
	$history_empowering_second_title = get_field('history_empowering_second_title');
	$history_empowering_content = get_field('history_empowering_content');
	?>
	<section class="empowering-part" data-aos="fade-up" data-aos-duration="1500">
    <div class="container">
      <div class="content-part">
        <div class="title">
          <h5><?php echo $history_empowering_first_title; ?></h5>
          <h2><?php echo $history_empowering_second_title; ?></h2>
        </div>
        <div class="para-content">
          <p><?php echo $history_empowering_content; ?></p>
        </div>
      </div>
    </div>
	</section>

	<section class="history-block-part">
		<div class="container">
			<div class="full-history-block">
				<?php if( have_rows('history_each_history') ): ?>
				<?php while( have_rows('history_each_history') ): the_row(); 
				$alignment = get_sub_field('alignment');
				$image = get_sub_field('image');
				$date = get_sub_field('date');
				$content = get_sub_field('content');
				?>
				<div class="single-history <?php echo $alignment; ?>">
					<div class="img-part">
						<img src="<?php echo $image['url']; ?>" alt="">
					</div>
					<div class="content">
						<h3><?php echo $date; ?></h3>
						<p><?php echo $content; ?></p>
					</div>
				</div>
				<?php endwhile; ?>
				<?php endif; ?>
				<!-- <div class="single-history align-right">
					<div class="img-part">
						<img src="assets/images/history-1993.png" alt="">
					</div>
					<div class="content">
						<h3>1993</h3>
						<p>ABPT initiated a joint venture with the Canadian company LeBlanc.</p>
					</div>
				</div>
				<div class="single-history align-left">
					<div class="img-part">
						<img src="assets/images/history-1999.png" alt="">
					</div>
					<div class="content">
						<h3>1999</h3>
						<p>ABPT expanded its operations into Egypt by setting up a manufacturing plant.</p>
					</div>
				</div>
				<div class="single-history align-right">
					<div class="img-part">
						<img src="assets/images/historty-2006.png" alt="">
					</div>
					<div class="content">
						<h3>2006</h3>
						<p>ABPT goes public and became a joint stock company.</p>
					</div>
				</div>
				<div class="single-history align-left">
					<div class="img-part">
						<img src="assets/images/history-2006-1.png" alt="">
					</div>
					<div class="content">
						<h3>2006</h3>
						<p>Al-Babtain LeBlanc (ABL) was established in UAE for Middle East Operations.</p>
					</div>
				</div>
				<div class="single-history align-right">
					<div class="img-part">
						<img src="assets/images/history-2011.png" alt="">
					</div>
					<div class="content">
						<h3>2011</h3>
						<p>Al-Babtain LeBlanc (ABL) was completely acquired by ABPT.</p>
					</div>
				</div>
				<div class="single-history align-left">
					<div class="img-part">
						<img src="assets/images/history-2012.png" alt="">
					</div>
					<div class="content">
						<h3>2012</h3>
						<p>ABPT acquired Petit Jean, a French lighting solutions and manufacturing company.</p>
					</div>
				</div>
				<div class="single-history align-right">
					<div class="img-part">
						<img src="assets/images/history-2014.png" alt="">
					</div>
					<div class="content">
						<h3>2014</h3>
						<p>Al-Babtain Contracting Qatar (ABCQ) was established in Doha.</p>
					</div>
				</div>
				<div class="single-history align-left">
					<div class="img-part">
						<img src="assets/images/history-2014-1.png" alt="">
					</div>
					<div class="content">
						<h3>2014</h3>
						<p>Integrated Lighting Company KSA (ILC KSA) was established to focus on innovative products and applications.</p>
					</div>
				</div>
				<div class="single-history align-right">
					<div class="img-part">
						<img src="assets/images/history-2015.png" alt="">
					</div>
					<div class="content">
						<h3>2015</h3>
						<p>ABITS UAE was established.</p>
					</div>
				</div>
				<div class="single-history align-left">
					<div class="img-part">
						<img src="assets/images/history-2016.png" alt="">
					</div>
					<div class="content">
						<h3>2016</h3>
						<p>Al-Babtain Lighting & Power Solutions (ABLP) Egypt was established to focus on innovative lighting products and applications in Egypt.</p>
					</div>
				</div>
				<div class="single-history align-right">
					<div class="img-part">
						<img src="assets/images/history-2017.png" alt="">
					</div>
					<div class="content">
						<h3>2017</h3>
						<p>ABPT diversified its activities by entering the renewable energy sector - PV solar, CSP Solar and wind energy solutions.</p>
					</div>
				</div> -->
			</div>
		</div>
	</section>