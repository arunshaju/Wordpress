<?php
/*

Template Name: Contact IR Page Template

*/
?>
<?php
$contact_ir_banner_image = get_field('contact_ir_banner_image');
$contact_ir_banner_first_title = get_field('contact_ir_banner_first_title');
$contact_ir_banner_second_title = get_field('contact_ir_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $contact_ir_banner_image['url']; ?>);">
	<div class="banner-layout">
		<div class="title container" data-aos="fade-up" data-aos-duration="1500">
				<h5><?php echo $contact_ir_banner_first_title; ?></h5>
				<h2><?php echo $contact_ir_banner_second_title; ?></h2>
		</div>
	</div>
</section>
<?php
$contact_ir_first_title = get_field('contact_ir_first_title');
$contact_ir_second_title = get_field('contact_ir_second_title');
?>
<section class="investor-relations-part investor-inner" data-aos="fade-up" data-aos-duration="1500">
	<div class="container">
		<div class="title" data-aos="fade-up" data-aos-duration="1500">
			<h5><?php echo $contact_ir_first_title; ?></h5>
			<h2><?php echo $contact_ir_second_title; ?></h2>
		</div>
		<div class="full-block-part" data-aos="fade-up" data-aos-duration="1500">
			<?php if( have_rows('contact_ir_contact_ir_block') ): ?>
			<?php while( have_rows('contact_ir_contact_ir_block') ): the_row(); 
			$image = get_sub_field('image');
			$title = get_sub_field('title');
			$content = get_sub_field('content');
			$mail_id = get_sub_field('mail_id');
			?>
			<div class="single">
				<div class="img-part">
					<img src="<?php echo $image['url']; ?>" alt="">
				</div>
				<div class="content">
					<h3><?php echo $title; ?></h3>
					<span><?php echo $content; ?></span>
					<div class="link">
						<a href="mailto:<?php echo $mail_id; ?>"><?php echo $mail_id; ?></a>
					</div>
				</div>
			</div>
			<?php endwhile; ?>.
			<?php endif; ?>
			<!-- <div class="single">
				<div class="img-part">
					<img src="assets/images/building.png" alt="">
				</div>
				<div class="content">
					<h3>institutional investor enquiries</h3>
					<span>Al-Babtain Power and Telecommunication Co</span>
					<div class="link">
						<a href="#">info@al-babtain.com.sa</a>
					</div>
				</div>
			</div> -->
		</div>
	</div>
</section>