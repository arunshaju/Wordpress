<?php
/*

Template Name: Contact Page Template

*/
?>
<?php
$contact_page_banner_image = get_field('contact_page_banner_image');
$contact_page_banner_first_title = get_field('contact_page_banner_first_title');
$contact_page_banner_second_title = get_field('contact_page_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $contact_page_banner_image['url']; ?>);">
  <div class="banner-layout">
    <div class="title container" data-aos="fade-up" data-aos-duration="1500">
        <h5><?php echo $contact_page_banner_first_title; ?></h5>
        <h2><?php echo $contact_page_banner_second_title; ?></h2>
    </div>
  </div>
</section>
<section class="join-full-part contact-full">
	<div class="container">
		<div class="full-block">
			<div class="left-block">
				<?php if( have_rows('contact_page_location_part') ): ?>
				<?php while( have_rows('contact_page_location_part') ): the_row(); 
				$map_slug = get_sub_field('map_slug');
				$title = get_sub_field('title');
				$address = get_sub_field('address');
				?>
				<div class="map-part">
					<div class="g-map">
							<iframe src="<?php echo $map_slug; ?>" width="100%" height="auto" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
					</div>
					<div class="address">
						<h3><?php echo $title; ?></h3>
						<?php echo $address; ?>
					</div>
				</div>
				<?php endwhile; ?>
				<?php endif; ?>
			</div>
			<?php
			$contact_contact_form = get_field('contact_contact_form');
			$contact_contact_form_arabic = get_field('contact_contact_form_arabic');
			?>
			<?php
			$build_your_feature_text = get_field('build_your_feature_text','option');
			?>
			<div class="right-block">
				<div class="right-block-inner">
					<div class="title">
						<h5><?php echo $build_your_feature_text; ?></h5>
					</div>
					<?php if(get_bloginfo('language')=='en-US') 
					{ ?>
					<?php echo $contact_contact_form; ?>
					<?php } else { ?>
					<?php echo $contact_contact_form_arabic; ?>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
</section>