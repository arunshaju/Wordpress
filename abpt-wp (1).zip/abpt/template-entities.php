<?php
/*

Template Name: Entities Template

*/
?>
<?php
$entities_banner_image = get_field('entities_banner_image');
$entities_banner_first_title = get_field('entities_banner_first_title');
$entities_banner_second_title = get_field('entities_banner_second_title');
?>
<section class="inner-banner" style="background-image: url(<?php echo $entities_banner_image['url']; ?>);">
	<div class="banner-layout">
		<div class="title container" data-aos="fade-up" data-aos-duration="1500">
				<h5><?php echo $entities_banner_first_title; ?></h5>
				<h2><?php echo $entities_banner_second_title; ?></h2>
		</div>
	</div>
</section>

<section class="full-energy-sec">
	<div class="container">
		<div class="full-energy-cont">
			<div class="title">
				<!-- <h2>PV SOLAR</h2> -->
			</div>
			<div class="energy-full">
				<?php if( have_rows('entities_each_entities_block') ): ?>
				<?php while( have_rows('entities_each_entities_block') ): the_row(); 
					$image = get_sub_field('image');
					$title = get_sub_field('title');
					$cta_text = get_sub_field('cta_text');
					$cta_link = get_sub_field('cta_link');
				?>
				<div class="single">
					<img src="<?php echo $image['url']; ?>" alt="">
					<h3><?php echo $title; ?></h3>
					<a href="<?php echo $cta_link; ?>" class="learn-more" target="blank" ><?php echo $cta_text; ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
				</div>
				<?php endwhile; ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>